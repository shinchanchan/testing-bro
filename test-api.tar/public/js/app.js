(function () {
  const socket = typeof io !== 'undefined' ? io() : null;

  window.subscribeUser = function (userId) {
    if (socket) socket.emit('subscribe', userId);
  };

  if (socket) {
    socket.on('whatsapp:qr', (data) => {
      const el = document.getElementById('qr-container');
      if (el) el.innerHTML = `<img src="${data.dataUrl}" alt="QR Code" class="rounded-xl mx-auto">`;
      const statusEl = document.getElementById('wa-status');
      if (statusEl) { statusEl.textContent = 'Scan QR Code'; statusEl.className = 'badge badge-warning'; }
    });

    socket.on('whatsapp:connected', () => {
      const el = document.getElementById('qr-container');
      if (el) el.innerHTML = '<div class="text-success text-center font-bold">Connected</div>';
      const statusEl = document.getElementById('wa-status');
      if (statusEl) { statusEl.textContent = 'Connected'; statusEl.className = 'badge badge-success'; }
    });

    socket.on('whatsapp:disconnected', () => {
      const statusEl = document.getElementById('wa-status');
      if (statusEl) { statusEl.textContent = 'Disconnected'; statusEl.className = 'badge badge-error'; }
    });
  }

  window.copyToClipboard = function (text) {
    navigator.clipboard.writeText(text).then(() => alert('Copied!'));
  };
})();
