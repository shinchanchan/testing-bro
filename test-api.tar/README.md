# ParroByte WhatsApp API

A production-grade SaaS platform to connect one WhatsApp account per user via QR code and send messages through REST APIs. Built with **Node.js, Express, whatsapp-web.js, Socket.IO, EJS, TailwindCSS, DaisyUI, and Razorpay**.

## Features

- QR-based WhatsApp connection (one account per user)
- REST API for text, image, video and document messages
- JWT authentication + API key authentication
- Razorpay billing (Starter monthly/yearly)
- Webhooks with HMAC signatures and retries
- Admin panel with CSV exports
- Help center + support tickets
- Filesystem-only storage (CSV + JSON)
- Helmet, CORS, rate limiting, input validation, audit logs

## Quick Start

```bash
# 1. Clone and install
git clone <repo>
cd parrobyte-whatsapp-api
npm install

# 2. Configure environment
cp .env.example .env
# Edit .env with your secrets and Razorpay keys

# 3. Run
npm run dev
```

Open http://localhost:3001 (or the port in your `.env`).

## Scripts

- `npm run dev` — start with nodemon
- `npm start` — production start
- `npm run build` — placeholder (no build step for EJS)

## Environment Variables

See `.env.example` for required variables. At minimum set:

- `JWT_SECRET`
- `SESSION_SECRET`
- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`

## API Usage

```bash
curl -X POST http://localhost:3001/api/send/text \
  -H "Authorization: Bearer pb_live_xxx" \
  -H "Content-Type: application/json" \
  -d '{"phone":"919999999999","message":"Hello"}'
```

Generate API keys from **Dashboard → API Keys**.

## Docker

```bash
docker compose up --build -d
```

Data, logs and uploads are persisted via Docker volumes.

## PM2 (Ubuntu)

```bash
npm install -g pm2
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

## Nginx + HTTPS

Use the provided `nginx.conf` as a template. Obtain SSL certificates with Certbot:

```bash
sudo certbot --nginx -d yourdomain.com
```

## Security

See `SECURITY.md` for the security checklist.

## License

MIT
