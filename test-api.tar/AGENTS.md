# AGENTS.md — ParroByte WhatsApp API

## Project Quick Reference
- **Stack**: Node.js 20+ · Express · whatsapp-web.js · Socket.IO · EJS · TailwindCSS CDN · DaisyUI CDN
- **Storage**: Filesystem only — CSV files under `data/` and JSON files under `data/tickets/`.
- **Auth**: JWT in httpOnly cookie for web; API key (`Authorization: Bearer <key>`) for programmatic access.
- **Theme**: White/black glassmorphism — `backdrop-filter: blur(20px)`, `rgba(255,255,255,0.08)`, `1px solid rgba(255,255,255,0.15)`.

## Commands
- `npm install` — install dependencies.
- `npm run dev` — start with nodemon.
- `npm start` — production start.

## Conventions
- Use `src/config/` for env-driven configuration.
- Use `src/services/` for business logic and external integrations.
- Use `src/utils/` for cross-cutting helpers (logger, crypto, CSV).
- Use async/await; centralize errors with `next(error)`.
- Keep EJS views under `views/`; shared components in `views/partials/`.
- Never commit `data/`, `logs/`, or `.env`.

## Adding Features
1. Add CSV schema columns to the initializer if storage changes.
2. Add validators under `src/validators/`.
3. Add controllers under `src/controllers/`.
4. Wire routes under `src/routes/` and mount in `server.js`.
5. Add view if needed and update layout partials.
6. Log security events to `audit_logs.csv`.

## Security Notes
- All user input must pass `express-validator`.
- API keys are hashed in memory only during verification; stored plaintext for retrieval/copy.
- Session files are encrypted at rest with `SESSION_SECRET`.
- Helmet + CORS + rate-limiting are mandatory in production.
