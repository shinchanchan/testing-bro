const express = require('express');
const http = require('http');
const path = require('path');
const ejsLayouts = require('express-ejs-layouts');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const cors = require('cors');
const methodOverride = require('method-override');
const { Server } = require('socket.io');

const config = require('./src/config');
const dataService = require('./src/services/dataService');
const whatsappService = require('./src/services/whatsappService');
const webhookService = require('./src/services/webhookService');
const { logger } = require('./src/utils/logger');
const { standard } = require('./src/middleware/rateLimiters');
const errorHandler = require('./src/middleware/errorHandler');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

whatsappService.setSocketIo(io);

io.on('connection', (socket) => {
  socket.on('subscribe', (userId) => {
    socket.join(`user:${userId}`);
    const status = whatsappService.getStatus(userId);
    const qr = whatsappService.getQr(userId);
    socket.emit('whatsapp:status', status);
    if (qr) socket.emit('whatsapp:qr', { dataUrl: qr.dataUrl });
  });
});

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(ejsLayouts);
app.set('layout', 'layouts/main');

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://cdn.tailwindcss.com", "https://cdn.jsdelivr.net", "https://fonts.googleapis.com"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'", "https://cdn.tailwindcss.com", "https://cdn.jsdelivr.net", "https://unpkg.com", "https://translate.googleapis.com", "https://translate.google.com"],
      imgSrc: ["'self'", "data:", "blob:", "https:"],
      connectSrc: ["'self'", "https://api.razorpay.com", "https://translate.googleapis.com", "https://translate.google.com", "wss:", "ws:"],
      fontSrc: ["'self'", "https:", "data:"],
      frameSrc: ["'self'", "https://translate.google.com"],
      scriptSrcAttr: ["'self'", "'unsafe-inline'"],
    },
  },
  crossOriginEmbedderPolicy: false,
  crossOriginResourcePolicy: { policy: 'cross-origin' },
}));
app.use(cors({ origin: config.env === 'production' ? config.appUrl : true }));
app.use(standard);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(methodOverride('_method'));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use((req, res, next) => {
  res.locals.appName = config.appName;
  res.locals.appUrl = config.appUrl;
  res.locals.user = req.user || null;
  res.locals.query = req.query;
  next();
});

app.use('/', require('./src/routes/public'));
app.use('/auth', require('./src/routes/auth'));
app.use('/dashboard', require('./src/routes/dashboard'));
app.use('/api', require('./src/routes/api'));
app.use('/billing', require('./src/routes/billing'));
app.use('/webhooks', require('./src/routes/webhook'));
app.use('/admin', require('./src/routes/admin'));
app.use('/help', require('./src/routes/help'));

app.get('/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

app.use(errorHandler);

const start = async () => {
  await dataService.initFiles();
  await dataService.seedAdmin();
  // Try to restore sessions, but don't fail boot if WhatsApp deps are missing
  try {
    await whatsappService.restoreSessions();
  } catch (err) {
    logger.warn('WhatsApp session restore skipped', { error: err.message });
  }

  server.listen(config.port, () => {
    logger.info(`${config.appName} running on port ${config.port} in ${config.env} mode`);
  });
};

start().catch((err) => {
  logger.error('Failed to start server', { error: err.message });
  process.exit(1);
});
