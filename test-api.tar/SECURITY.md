# Security Checklist

## Implemented

- [x] Helmet for HTTP security headers
- [x] CORS configured per environment
- [x] Express rate limiting (global, auth, API)
- [x] JWT in httpOnly cookies
- [x] bcrypt password hashing
- [x] Encrypted WhatsApp session files at rest
- [x] express-validator input validation
- [x] Multer file upload limits and type filtering
- [x] Audit logs for login, payment, API, messaging
- [x] API key authentication separate from web sessions
- [x] Razorpay signature verification
- [x] Webhook HMAC signature verification

## Deployment Hardening

- [ ] Use HTTPS in production (Nginx + Certbot)
- [ ] Keep `.env` out of source control
- [ ] Restrict server SSH access
- [ ] Run app as non-root user
- [ ] Enable UFW firewall (allow 80/443 only)
- [ ] Configure log rotation
- [ ] Keep dependencies updated (`npm audit fix`)
- [ ] Use strong, unique JWT and session secrets
- [ ] Set Razorpay live keys only in production
