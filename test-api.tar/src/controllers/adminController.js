const fs = require('fs');
const path = require('path');
const dataService = require('../services/dataService');
const paymentService = require('../services/paymentService');
const messageService = require('../services/messageService');
const whatsappService = require('../services/whatsappService');
const { audit } = require('../utils/audit');
const csv = require('../utils/csv');
const config = require('../config');

const ticketDir = path.resolve(config.paths.tickets);

const summary = async () => {
  const [users, payments, messages, logs] = await Promise.all([
    dataService.listUsers(),
    dataService.listPayments(),
    dataService.listMessages(1000),
    dataService.listAuditLogs(100),
  ]);

  const revenue = payments
    .filter((p) => p.status === 'verified')
    .reduce((sum, p) => sum + (parseFloat(p.amount) || 0), 0);

  return {
    totalUsers: users.length,
    activeUsers: users.filter((u) => u.status === 'active').length,
    revenue,
    totalMessages: messages.length,
    pendingPayments: payments.filter((p) => p.status === 'created').length,
    recentPayments: payments.slice(-10).reverse(),
    recentMessages: messages.slice(-10),
    users: users.slice(-20).reverse(),
    logs,
  };
};

exports.dashboard = async (req, res, next) => {
  try {
    const data = await summary();
    res.render('admin/dashboard', { title: 'Admin Dashboard', section: 'dashboard', user: req.user, ...data });
  } catch (err) {
    next(err);
  }
};

exports.users = async (req, res, next) => {
  try {
    const users = await dataService.listUsers();
    res.render('admin/users', { title: 'Users', section: 'users', user: req.user, users });
  } catch (err) {
    next(err);
  }
};

exports.updateUser = async (req, res, next) => {
  try {
    const { status } = req.body;
    await dataService.updateUser(req.params.id, { status });
    await audit({ userId: req.user.id, action: 'admin_user_update', ip: req.ip, userAgent: req.headers['user-agent'], meta: { targetUser: req.params.id, status } });
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
};

exports.payments = async (req, res, next) => {
  try {
    const payments = await dataService.listPayments();
    res.render('admin/payments', { title: 'Payments', section: 'payments', user: req.user, payments });
  } catch (err) {
    next(err);
  }
};

exports.verifyPayment = async (req, res, next) => {
  try {
    await paymentService.manualVerify(req.params.id);
    await audit({ userId: req.user.id, action: 'admin_payment_verify', ip: req.ip, userAgent: req.headers['user-agent'], meta: { paymentId: req.params.id } });
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
};

exports.messages = async (req, res, next) => {
  try {
    const messages = await dataService.listMessages(500);
    res.render('admin/messages', { title: 'Messages', section: 'messages', user: req.user, messages });
  } catch (err) {
    next(err);
  }
};

exports.support = async (req, res, next) => {
  try {
    const files = fs.existsSync(ticketDir) ? fs.readdirSync(ticketDir).filter((f) => f.endsWith('.json')) : [];
    const tickets = files
      .map((f) => JSON.parse(fs.readFileSync(path.join(ticketDir, f), 'utf8')))
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    res.render('admin/support', { title: 'Support Tickets', section: 'support', user: req.user, tickets });
  } catch (err) {
    next(err);
  }
};

exports.exportCsv = async (req, res, next) => {
  try {
    const { type } = req.params;
    const fileMap = {
      users: dataService.FILES.users,
      payments: dataService.FILES.payments,
      messages: dataService.FILES.messages,
      apikeys: dataService.FILES.apiKeys,
      audit: dataService.FILES.auditLogs,
    };
    const src = fileMap[type];
    if (!src) throw new Error('Invalid export type');
    const rows = await csv.readCsv(src);
    const exportPath = path.resolve(config.paths.data, `export_${type}_${Date.now()}.csv`);
    await csv.writeCsv(exportPath, dataService.HEADERS[type === 'apikeys' ? 'apiKeys' : type], rows);
    res.download(exportPath, `parrobyte_${type}.csv`);
  } catch (err) {
    next(err);
  }
};
