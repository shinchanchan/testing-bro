const fs = require('fs');
const path = require('path');
const { validationResult } = require('express-validator');
const dataService = require('../services/dataService');
const { signToken, setAuthCookie, clearAuthCookie } = require('../middleware/auth');
const { audit } = require('../utils/audit');
const { randomToken, now } = require('../utils/helpers');
const config = require('../config');

const TOKEN_FILE = path.resolve(config.paths.data, 'verification_tokens.json');

const readTokens = () => {
  if (!fs.existsSync(TOKEN_FILE)) return {};
  try {
    return JSON.parse(fs.readFileSync(TOKEN_FILE, 'utf8'));
  } catch {
    return {};
  }
};

const writeTokens = (tokens) => {
  fs.writeFileSync(TOKEN_FILE, JSON.stringify(tokens, null, 2));
};

const saveToken = (email, type) => {
  const tokens = readTokens();
  const token = randomToken();
  tokens[token] = { email, type, expires: Date.now() + 24 * 60 * 60 * 1000 };
  writeTokens(tokens);
  return token;
};

const validate = (req) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const err = new Error(errors.array()[0].msg);
    err.status = 400;
    throw err;
  }
};

const renderAuthError = (req, res, err) => {
  const back = req.headers.referer || '/auth/login';
  res.redirect(`${back}?error=${encodeURIComponent(err.message)}`);
};

exports.getLogin = (req, res) => res.render('auth/login', { title: 'Login', error: req.query.error || '' });
exports.getSignup = (req, res) => res.render('auth/signup', { title: 'Sign Up', error: req.query.error || '' });
exports.getForgot = (req, res) => res.render('auth/forgot', { title: 'Forgot Password', error: req.query.error || '' });
exports.getReset = (req, res) => res.render('auth/reset', { title: 'Reset Password', token: req.params.token, error: req.query.error || '' });

exports.postSignup = async (req, res, next) => {
  try {
    validate(req);
    const { name, email, password } = req.body;
    const user = await dataService.createUser({ name, email, password });
    const token = saveToken(email, 'verify');
    // In production, send email with verification link: `${config.appUrl}/auth/verify-email/${token}`
    console.log(`[email] Verify link: ${config.appUrl}/auth/verify-email/${token}`);
    const jwt = signToken({ id: user.id, role: user.role, email: user.email });
    setAuthCookie(res, jwt);
    res.redirect('/billing/plans');
  } catch (err) {
    renderAuthError(req, res, err);
  }
};

exports.postLogin = async (req, res, next) => {
  try {
    validate(req);
    const { email, password } = req.body;
    const user = await dataService.findUserByEmail(email);
    if (!user) throw new Error('Invalid credentials');

    const full = await dataService.findUserByIdWithHash(user.id);
    const valid = await dataService.verifyPassword(full, password);
    if (!valid) throw new Error('Invalid credentials');

    const token = signToken({ id: user.id, role: user.role, email: user.email });
    setAuthCookie(res, token);

    await audit({
      userId: user.id,
      action: 'login',
      ip: req.ip,
      userAgent: req.headers['user-agent'],
    });

    res.redirect(user.role === 'admin' ? '/admin' : '/dashboard');
  } catch (err) {
    renderAuthError(req, res, err);
  }
};

exports.logout = (req, res) => {
  clearAuthCookie(res);
  res.redirect('/');
};

exports.verifyEmail = async (req, res) => {
  try {
    const tokens = readTokens();
    const record = tokens[req.params.token];
    if (!record || record.type !== 'verify' || record.expires < Date.now()) {
      throw new Error('Invalid or expired token');
    }
    const user = await dataService.findUserByEmail(record.email);
    if (user) {
      await dataService.updateUser(user.id, { verified_at: now() });
    }
    delete tokens[req.params.token];
    writeTokens(tokens);
    res.redirect('/auth/login?message=Email verified. You can now log in.');
  } catch (err) {
    res.redirect(`/auth/login?error=${encodeURIComponent(err.message)}`);
  }
};

exports.postForgot = async (req, res, next) => {
  try {
    validate(req);
    const { email } = req.body;
    const user = await dataService.findUserByEmail(email);
    if (user) {
      const token = saveToken(email, 'reset');
      console.log(`[email] Reset link: ${config.appUrl}/auth/reset-password/${token}`);
    }
    res.redirect('/auth/login?message=If an account exists, a reset link has been sent.');
  } catch (err) {
    renderAuthError(req, res, err);
  }
};

exports.postReset = async (req, res, next) => {
  try {
    validate(req);
    const tokens = readTokens();
    const record = tokens[req.params.token];
    if (!record || record.type !== 'reset' || record.expires < Date.now()) {
      throw new Error('Invalid or expired token');
    }
    const user = await dataService.findUserByEmail(record.email);
    if (user) {
      const bcrypt = require('bcryptjs');
      const hash = await bcrypt.hash(req.body.password, config.bcryptRounds);
      await dataService.updateUser(user.id, { password_hash: hash });
    }
    delete tokens[req.params.token];
    writeTokens(tokens);
    res.redirect('/auth/login?message=Password updated. Please log in.');
  } catch (err) {
    renderAuthError(req, res, err);
  }
};
