const fs = require('fs');
const path = require('path');
const { generateId, now } = require('../utils/helpers');
const config = require('../config');

const ticketDir = path.resolve(config.paths.tickets);

const ensureTicketDir = () => {
  if (!fs.existsSync(ticketDir)) fs.mkdirSync(ticketDir, { recursive: true });
};

const getTicketPath = (id) => path.join(ticketDir, `${id}.json`);

const saveTicket = (ticket) => {
  ensureTicketDir();
  fs.writeFileSync(getTicketPath(ticket.id), JSON.stringify(ticket, null, 2));
};

const getTicket = (id) => {
  const p = getTicketPath(id);
  if (!fs.existsSync(p)) return null;
  return JSON.parse(fs.readFileSync(p, 'utf8'));
};

const listTickets = (userId, role) => {
  ensureTicketDir();
  return fs
    .readdirSync(ticketDir)
    .filter((f) => f.endsWith('.json'))
    .map((f) => JSON.parse(fs.readFileSync(path.join(ticketDir, f), 'utf8')))
    .filter((t) => role === 'admin' || t.user_id === userId)
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
};

exports.index = (req, res) => res.render('help/index', { title: 'Help Center', user: req.user });

exports.page = (req, res) => {
  const { slug } = req.params;
  const allowed = ['getting-started', 'api-docs', 'connect-whatsapp', 'webhook-guide', 'troubleshooting', 'pricing', 'faq'];
  if (!allowed.includes(slug)) return res.redirect('/help');
  res.render(`help/${slug.replace(/-/g, '_')}`, { title: slug.replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()), user: req.user });
};

exports.tickets = (req, res) => {
  const tickets = listTickets(req.user.id, req.user.role);
  res.render('help/tickets', { title: 'Support Tickets', user: req.user, tickets });
};

exports.createTicketView = (req, res) => res.render('help/ticket_create', { title: 'Create Ticket', user: req.user });

exports.createTicket = (req, res, next) => {
  try {
    const { subject, body } = req.body;
    const ticket = {
      id: generateId(),
      user_id: req.user.id,
      user_name: req.user.name,
      subject,
      body,
      status: 'open',
      replies: [],
      created_at: now(),
      updated_at: now(),
    };
    saveTicket(ticket);
    res.redirect('/help/tickets');
  } catch (err) {
    next(err);
  }
};

exports.ticketDetail = (req, res, next) => {
  try {
    const ticket = getTicket(req.params.id);
    if (!ticket) throw new Error('Ticket not found');
    if (ticket.user_id !== req.user.id && req.user.role !== 'admin') throw new Error('Forbidden');
    res.render('help/ticket_detail', { title: ticket.subject, user: req.user, ticket });
  } catch (err) {
    next(err);
  }
};

exports.replyTicket = (req, res, next) => {
  try {
    const ticket = getTicket(req.params.id);
    if (!ticket) throw new Error('Ticket not found');
    if (ticket.user_id !== req.user.id && req.user.role !== 'admin') throw new Error('Forbidden');
    ticket.replies.push({
      by: req.user.name,
      role: req.user.role,
      body: req.body.body,
      at: now(),
    });
    ticket.status = req.body.status || ticket.status;
    ticket.updated_at = now();
    saveTicket(ticket);
    res.redirect(`/help/tickets/${ticket.id}`);
  } catch (err) {
    next(err);
  }
};
