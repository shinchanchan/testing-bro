const { validationResult } = require('express-validator');
const crypto = require('crypto');
const dataService = require('../services/dataService');
const webhookService = require('../services/webhookService');
const config = require('../config');
const { audit } = require('../utils/audit');

const validate = (req) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const err = new Error(errors.array()[0].msg);
    err.status = 400;
    throw err;
  }
};

exports.list = async (req, res, next) => {
  try {
    const webhooks = await dataService.listWebhooksByUser(req.user.id);
    res.json({ success: true, data: webhooks });
  } catch (err) {
    next(err);
  }
};

exports.create = async (req, res, next) => {
  try {
    validate(req);
    const { url, events } = req.body;
    const secret = `${config.webhook.secretPrefix}${crypto.randomBytes(16).toString('hex')}`;
    const webhook = await dataService.createWebhook({
      user_id: req.user.id,
      url,
      secret,
      events: events.split(',').map((e) => e.trim()).join(','),
      status: 'active',
    });
    await audit({ userId: req.user.id, action: 'webhook_create', ip: req.ip, userAgent: req.headers['user-agent'], meta: { url } });
    res.json({ success: true, data: webhook });
  } catch (err) {
    next(err);
  }
};

exports.update = async (req, res, next) => {
  try {
    validate(req);
    const { url, events, status } = req.body;
    await dataService.updateWebhook(req.params.id, req.user.id, { url, events, status });
    await audit({ userId: req.user.id, action: 'webhook_update', ip: req.ip, userAgent: req.headers['user-agent'], meta: { webhookId: req.params.id } });
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
};

exports.delete = async (req, res, next) => {
  try {
    await dataService.deleteWebhook(req.params.id, req.user.id);
    await audit({ userId: req.user.id, action: 'webhook_delete', ip: req.ip, userAgent: req.headers['user-agent'], meta: { webhookId: req.params.id } });
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
};

exports.test = async (req, res, next) => {
  try {
    const { event = 'message.sent' } = req.body;
    await webhookService.dispatch(req.user.id, event, {
      test: true,
      message_id: 'test-' + Date.now(),
      phone: '919999999999',
    });
    await audit({ userId: req.user.id, action: 'webhook_test', ip: req.ip, userAgent: req.headers['user-agent'], meta: { event } });
    res.json({ success: true, message: 'Test event dispatched' });
  } catch (err) {
    next(err);
  }
};
