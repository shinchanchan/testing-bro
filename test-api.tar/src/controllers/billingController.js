const { validationResult } = require('express-validator');
const dataService = require('../services/dataService');
const paymentService = require('../services/paymentService');
const { audit } = require('../utils/audit');
const config = require('../config');

const validate = (req) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const err = new Error(errors.array()[0].msg);
    err.status = 400;
    throw err;
  }
};

exports.plans = (req, res) => {
  res.render('billing/plans', {
    title: 'Pricing Plans',
    user: req.user,
    plans: paymentService.PLANS,
    keyId: config.razorpay.keyId,
  });
};

exports.checkout = (req, res) => {
  const { plan, type } = req.query;
  const price = paymentService.getPlanPrice(plan, type);
  if (!price) return res.redirect('/billing/plans?error=Invalid plan');
  res.render('billing/checkout', {
    title: 'Checkout',
    user: req.user,
    plan,
    type,
    amount: price,
    keyId: config.razorpay.keyId,
  });
};

exports.createOrder = async (req, res, next) => {
  try {
    const { plan, type } = req.body;
    const order = await paymentService.createOrder({ userId: req.user.id, plan, planType: type });
    await audit({ userId: req.user.id, action: 'payment_order_created', ip: req.ip, userAgent: req.headers['user-agent'], meta: { plan, type } });
    res.json({ success: true, data: order });
  } catch (err) {
    next(err);
  }
};

exports.verify = async (req, res, next) => {
  try {
    const { orderId, paymentId, signature } = req.body;
    const result = await paymentService.verifyPayment({ userId: req.user.id, orderId, paymentId, signature });
    await audit({ userId: req.user.id, action: 'payment_verified', ip: req.ip, userAgent: req.headers['user-agent'], meta: { orderId } });
    res.json({ success: true, data: result });
  } catch (err) {
    next(err);
  }
};
