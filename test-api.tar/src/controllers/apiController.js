const { validationResult } = require('express-validator');
const path = require('path');
const fs = require('fs');
const dataService = require('../services/dataService');
const messageService = require('../services/messageService');
const webhookService = require('../services/webhookService');
const { audit } = require('../utils/audit');
const { messagingLogger, apiLogger } = require('../utils/logger');
const config = require('../config');

const validate = (req) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const err = new Error(errors.array()[0].msg);
    err.status = 400;
    throw err;
  }
};

const sendApiResponse = (req, res, next, handler) =>
  handler()
    .then((data) => res.json({ success: true, data }))
    .catch(next);

exports.sendText = (req, res, next) => {
  sendApiResponse(req, res, next, async () => {
    validate(req);
    const { phone, message } = req.body;
    const job = await messageService.createJob({
      userId: req.user.id,
      phone,
      type: 'text',
      message,
    });
    apiLogger.info('Text message queued', { userId: req.user.id, messageId: job.id });
    await audit({ userId: req.user.id, action: 'api_send_text', ip: req.ip, userAgent: req.headers['user-agent'], meta: { phone } });
    return { messageId: job.id, status: job.status };
  });
};

exports.sendImage = (req, res, next) => {
  sendApiResponse(req, res, next, async () => {
    validate(req);
    if (!req.file) throw new Error('Image file required');
    const { phone, caption } = req.body;
    const job = await messageService.createJob({
      userId: req.user.id,
      phone,
      type: 'image',
      caption,
      mediaPath: req.file.path,
    });
    apiLogger.info('Image message queued', { userId: req.user.id, messageId: job.id });
    await audit({ userId: req.user.id, action: 'api_send_image', ip: req.ip, userAgent: req.headers['user-agent'], meta: { phone } });
    return { messageId: job.id, status: job.status };
  });
};

exports.sendVideo = (req, res, next) => {
  sendApiResponse(req, res, next, async () => {
    validate(req);
    if (!req.file) throw new Error('Video file required');
    const { phone, caption } = req.body;
    const job = await messageService.createJob({
      userId: req.user.id,
      phone,
      type: 'video',
      caption,
      mediaPath: req.file.path,
    });
    apiLogger.info('Video message queued', { userId: req.user.id, messageId: job.id });
    await audit({ userId: req.user.id, action: 'api_send_video', ip: req.ip, userAgent: req.headers['user-agent'], meta: { phone } });
    return { messageId: job.id, status: job.status };
  });
};

exports.sendFile = (req, res, next) => {
  sendApiResponse(req, res, next, async () => {
    validate(req);
    if (!req.file) throw new Error('Document file required');
    const { phone, caption } = req.body;
    const job = await messageService.createJob({
      userId: req.user.id,
      phone,
      type: 'document',
      caption,
      mediaPath: req.file.path,
    });
    apiLogger.info('Document message queued', { userId: req.user.id, messageId: job.id });
    await audit({ userId: req.user.id, action: 'api_send_file', ip: req.ip, userAgent: req.headers['user-agent'], meta: { phone } });
    return { messageId: job.id, status: job.status };
  });
};

exports.createApiKey = async (req, res, next) => {
  try {
    validate(req);
    const { type } = req.body;
    const expiresAt = new Date();
    expiresAt.setFullYear(expiresAt.getFullYear() + 1);
    const key = await dataService.createApiKey({
      userId: req.user.id,
      type,
      expiresAt: expiresAt.toISOString(),
    });
    await audit({ userId: req.user.id, action: 'api_key_create', ip: req.ip, userAgent: req.headers['user-agent'], meta: { type } });
    res.json({ success: true, data: key });
  } catch (err) {
    next(err);
  }
};

exports.listApiKeys = async (req, res, next) => {
  try {
    const keys = await dataService.listApiKeysByUser(req.user.id);
    res.json({ success: true, data: keys });
  } catch (err) {
    next(err);
  }
};

exports.revokeApiKey = async (req, res, next) => {
  try {
    await dataService.revokeApiKey(req.params.id, req.user.id);
    await audit({ userId: req.user.id, action: 'api_key_revoke', ip: req.ip, userAgent: req.headers['user-agent'], meta: { keyId: req.params.id } });
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
};

exports.getStatus = async (req, res, next) => {
  try {
    const stats = await messageService.getStats(req.user.id);
    res.json({ success: true, data: stats });
  } catch (err) {
    next(err);
  }
};
