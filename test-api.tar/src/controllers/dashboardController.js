const whatsappService = require('../services/whatsappService');
const messageService = require('../services/messageService');
const dataService = require('../services/dataService');
const paymentService = require('../services/paymentService');
const { audit } = require('../utils/audit');
const { validationResult } = require('express-validator');

const validate = (req) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const err = new Error(errors.array()[0].msg);
    err.status = 400;
    throw err;
  }
};

const shared = async (req) => {
  const [messages, apiKeys, webhooks, payments] = await Promise.all([
    messageService.listByUser(req.user.id, 10),
    dataService.listApiKeysByUser(req.user.id),
    dataService.listWebhooksByUser(req.user.id),
    dataService.listPaymentsByUser(req.user.id),
  ]);
  const stats = await messageService.getStats(req.user.id);
  const status = whatsappService.getStatus(req.user.id);
  const qr = whatsappService.getQr(req.user.id);
  return { user: req.user, messages, apiKeys, webhooks, payments, stats, status, qr };
};

exports.index = async (req, res, next) => {
  try {
    const data = await shared(req);
    res.render('dashboard/overview', { title: 'Dashboard', section: 'overview', ...data });
  } catch (err) {
    next(err);
  }
};

exports.send = async (req, res, next) => {
  try {
    const data = await shared(req);
    res.render('dashboard/send', { title: 'Send Message', section: 'send', ...data });
  } catch (err) {
    next(err);
  }
};

exports.contacts = async (req, res, next) => {
  try {
    const data = await shared(req);
    res.render('dashboard/contacts', { title: 'Contacts', section: 'contacts', ...data });
  } catch (err) {
    next(err);
  }
};

exports.api = async (req, res, next) => {
  try {
    const data = await shared(req);
    res.render('dashboard/api', { title: 'API Keys', section: 'api', ...data });
  } catch (err) {
    next(err);
  }
};

exports.webhooks = async (req, res, next) => {
  try {
    const data = await shared(req);
    res.render('dashboard/webhooks', { title: 'Webhooks', section: 'webhooks', ...data });
  } catch (err) {
    next(err);
  }
};

exports.billing = async (req, res, next) => {
  try {
    const data = await shared(req);
    res.render('dashboard/billing', { title: 'Billing', section: 'billing', ...data, plans: paymentService.PLANS });
  } catch (err) {
    next(err);
  }
};

exports.help = async (req, res, next) => {
  try {
    const data = await shared(req);
    res.render('dashboard/help', { title: 'Help', section: 'help', ...data });
  } catch (err) {
    next(err);
  }
};

exports.connectWhatsApp = async (req, res, next) => {
  try {
    const result = await whatsappService.connect(req.user.id);
    await audit({ userId: req.user.id, action: 'whatsapp_connect', ip: req.ip, userAgent: req.headers['user-agent'] });
    res.json({ success: true, ...result });
  } catch (err) {
    next(err);
  }
};

exports.disconnectWhatsApp = async (req, res, next) => {
  try {
    await whatsappService.disconnect(req.user.id);
    await audit({ userId: req.user.id, action: 'whatsapp_disconnect', ip: req.ip, userAgent: req.headers['user-agent'] });
    res.json({ success: true, status: 'disconnected' });
  } catch (err) {
    next(err);
  }
};

exports.sendText = async (req, res, next) => {
  try {
    validate(req);
    const { phone, message } = req.body;
    const job = await messageService.createJob({ userId: req.user.id, phone, type: 'text', message });
    await audit({ userId: req.user.id, action: 'dashboard_send_text', ip: req.ip, userAgent: req.headers['user-agent'], meta: { phone } });
    res.json({ success: true, data: { messageId: job.id, status: job.status } });
  } catch (err) {
    next(err);
  }
};

exports.sendMedia = async (req, res, next) => {
  try {
    validate(req);
    const type = req.params.type;
    if (!req.file) throw new Error('File required');
    const { phone, caption } = req.body;
    const job = await messageService.createJob({ userId: req.user.id, phone, type, caption, mediaPath: req.file.path });
    await audit({ userId: req.user.id, action: 'dashboard_send_' + type, ip: req.ip, userAgent: req.headers['user-agent'], meta: { phone } });
    res.json({ success: true, data: { messageId: job.id, status: job.status } });
  } catch (err) {
    next(err);
  }
};
