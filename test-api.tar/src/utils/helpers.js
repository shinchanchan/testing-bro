const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const dayjs = require('dayjs');

const now = () => dayjs().toISOString();

const generateId = () => uuidv4();

const slugify = (text) =>
  text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^\w\-]+/g, '')
    .replace(/\-\-+/g, '-');

const sanitizePhone = (phone, defaultCountry = '91') => {
  if (!phone) return null;
  let cleaned = phone.toString().replace(/[^\d]/g, '');
  if (cleaned.length === 10) cleaned = defaultCountry + cleaned;
  if (cleaned.length < 10 || cleaned.length > 15) return null;
  return cleaned;
};

const fileHash = (buffer) => crypto.createHash('sha256').update(buffer).digest('hex');

const maskKey = (key) => {
  if (!key || key.length < 12) return key;
  return `${key.slice(0, 8)}...${key.slice(-4)}`;
};

const randomToken = (bytes = 32) => crypto.randomBytes(bytes).toString('hex');

const toNumber = (value, fallback = 0) => {
  const n = Number(value);
  return Number.isNaN(n) ? fallback : n;
};

module.exports = {
  now,
  generateId,
  slugify,
  sanitizePhone,
  fileHash,
  maskKey,
  randomToken,
  toNumber,
};
