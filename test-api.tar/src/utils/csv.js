const fs = require('fs');
const path = require('path');
const csvParser = require('csv-parser');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;

const ensureDir = (filePath) => {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
};

const readCsv = (filePath) =>
  new Promise((resolve, reject) => {
    const rows = [];
    if (!fs.existsSync(filePath)) return resolve(rows);
    fs.createReadStream(filePath)
      .pipe(csvParser())
      .on('data', (row) => rows.push(row))
      .on('end', () => resolve(rows))
      .on('error', reject);
  });

const writeCsv = async (filePath, headers, rows) => {
  ensureDir(filePath);
  const writer = createCsvWriter({ path: filePath, header: headers.map((h) => ({ id: h, title: h })) });
  await writer.writeRecords(rows);
};

const appendCsv = async (filePath, headers, row) => {
  ensureDir(filePath);
  const exists = fs.existsSync(filePath);
  const writer = createCsvWriter({
    path: filePath,
    header: headers.map((h) => ({ id: h, title: h })),
    append: exists,
  });
  await writer.writeRecords([row]);
};

const updateCsv = async (filePath, headers, predicate, updater) => {
  const rows = await readCsv(filePath);
  const updated = rows.map((row) => (predicate(row) ? { ...row, ...updater(row) } : row));
  await writeCsv(filePath, headers, updated);
  return updated;
};

const findOne = async (filePath, predicate) => {
  const rows = await readCsv(filePath);
  return rows.find(predicate) || null;
};

module.exports = { readCsv, writeCsv, appendCsv, updateCsv, findOne, ensureDir };
