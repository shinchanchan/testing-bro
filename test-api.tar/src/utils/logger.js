const path = require('path');
const winston = require('winston');
require('winston-daily-rotate-file');
const config = require('../config');

const { combine, timestamp, json, errors, printf } = winston.format;

const logDir = path.resolve(config.paths.logs);

const dailyRotate = (name) =>
  new winston.transports.DailyRotateFile({
    filename: path.join(logDir, `${name}-%DATE%.log`),
    datePattern: 'YYYY-MM-DD',
    zippedArchive: true,
    maxSize: '20m',
    maxFiles: '14d',
  });

const consoleFormat = printf(({ level, message, timestamp: ts, ...metadata }) => {
  let meta = '';
  if (Object.keys(metadata).length) {
    meta = JSON.stringify(metadata);
  }
  return `${ts} [${level.toUpperCase()}]: ${message} ${meta}`;
});

const logger = winston.createLogger({
  level: config.env === 'production' ? 'info' : 'debug',
  defaultMeta: { service: 'parrobyte' },
  transports: [
    dailyRotate('combined'),
    dailyRotate('error'),
    new winston.transports.Console({
      format: combine(timestamp(), consoleFormat),
    }),
  ],
  exceptionHandlers: [dailyRotate('exceptions')],
  rejectionHandlers: [dailyRotate('rejections')],
});

const categoryLogger = (category) => ({
  info: (message, meta = {}) => logger.info(message, { category, ...meta }),
  warn: (message, meta = {}) => logger.warn(message, { category, ...meta }),
  error: (message, meta = {}) => logger.error(message, { category, ...meta }),
  debug: (message, meta = {}) => logger.debug(message, { category, ...meta }),
});

module.exports = {
  logger,
  loginLogger: categoryLogger('login'),
  apiLogger: categoryLogger('api'),
  paymentLogger: categoryLogger('payment'),
  messagingLogger: categoryLogger('messaging'),
};
