const { generateId, now } = require('./helpers');
const csv = require('./csv');
const config = require('../config');
const path = require('path');

const HEADERS = ['id', 'user_id', 'action', 'ip', 'user_agent', 'meta', 'created_at'];
const FILE = path.join(config.paths.data, 'audit_logs.csv');

const audit = async ({ userId = '', action, ip = '', userAgent = '', meta = {} }) => {
  try {
    const row = {
      id: generateId(),
      user_id: userId,
      action,
      ip: ip || '',
      user_agent: userAgent || '',
      meta: JSON.stringify(meta).replace(/"/g, '""'),
      created_at: now(),
    };
    await csv.appendCsv(FILE, HEADERS, row);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('[audit] Failed to write audit log:', err.message);
  }
};

module.exports = { audit };
