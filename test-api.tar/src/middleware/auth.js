const jwt = require('jsonwebtoken');
const config = require('../config');
const dataService = require('../services/dataService');
const { audit } = require('../utils/audit');

const TOKEN_COOKIE = 'pb_token';

const signToken = (payload) => jwt.sign(payload, config.jwtSecret, { expiresIn: '7d' });

const setAuthCookie = (res, token) => {
  res.cookie(TOKEN_COOKIE, token, {
    httpOnly: true,
    secure: config.env === 'production',
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000,
  });
};

const clearAuthCookie = (res) => {
  res.clearCookie(TOKEN_COOKIE);
};

const authenticate = async (req, res, next) => {
  try {
    const token = req.cookies?.[TOKEN_COOKIE] || req.headers.authorization?.replace('Bearer ', '');
    if (!token) throw new Error('Authentication required');

    const decoded = jwt.verify(token, config.jwtSecret);
    const user = await dataService.findUserById(decoded.id);
    if (!user) throw new Error('User not found');
    if (user.status === 'blocked') throw new Error('Account blocked');

    req.user = user;
    next();
  } catch (err) {
    err.status = 401;
    next(err);
  }
};

const authenticateApi = async (req, res, next) => {
  try {
    const header = req.headers.authorization || '';
    const key = header.replace('Bearer ', '').trim();
    if (!key) throw new Error('API key required');

    const apiKey = await dataService.findApiKey(key);
    if (!apiKey) throw new Error('Invalid API key');

    const user = await dataService.findUserById(apiKey.user_id);
    if (!user) throw new Error('User not found');
    if (user.status === 'blocked') throw new Error('Account blocked');

    await dataService.incrementApiKeyUsage(key);
    req.user = user;
    req.apiKey = apiKey;
    next();
  } catch (err) {
    err.status = 401;
    next(err);
  }
};

const authenticateAny = async (req, res, next) => {
  try {
    const header = req.headers.authorization || '';
    const key = header.replace('Bearer ', '').trim();
    if (key) {
      const apiKey = await dataService.findApiKey(key);
      if (apiKey) {
        const user = await dataService.findUserById(apiKey.user_id);
        if (!user) throw new Error('User not found');
        if (user.status === 'blocked') throw new Error('Account blocked');
        await dataService.incrementApiKeyUsage(key);
        req.user = user;
        req.apiKey = apiKey;
        return next();
      }
    }

    const token = req.cookies?.[TOKEN_COOKIE];
    if (!token) throw new Error('Authentication required');
    const decoded = jwt.verify(token, config.jwtSecret);
    const user = await dataService.findUserById(decoded.id);
    if (!user) throw new Error('User not found');
    if (user.status === 'blocked') throw new Error('Account blocked');
    req.user = user;
    next();
  } catch (err) {
    err.status = 401;
    next(err);
  }
};

const requireRole = (...roles) => (req, res, next) => {
  if (!req.user || !roles.includes(req.user.role)) {
    const err = new Error('Forbidden');
    err.status = 403;
    return next(err);
  }
  next();
};

module.exports = { signToken, setAuthCookie, clearAuthCookie, authenticate, authenticateApi, authenticateAny, requireRole };
