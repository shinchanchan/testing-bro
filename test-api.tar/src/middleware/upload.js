const multer = require('multer');
const path = require('path');
const config = require('../config');
const { ensureDir } = require('../utils/csv');

const MAX_SIZE = config.uploads.maxFileSizeMb * 1024 * 1024;

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.resolve(config.paths.uploads);
    ensureDir(dir);
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}${path.extname(file.originalname)}`;
    cb(null, unique);
  },
});

const fileFilter = (req, file, cb) => {
  const allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'video/mp4', 'application/pdf', 'text/csv'];
  if (allowed.includes(file.mimetype)) return cb(null, true);
  cb(new Error('Invalid file type'));
};

const upload = multer({ storage, limits: { fileSize: MAX_SIZE }, fileFilter });

module.exports = upload;
