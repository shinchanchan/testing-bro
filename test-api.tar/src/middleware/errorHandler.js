const { logger } = require('../utils/logger');

const errorHandler = (err, req, res, next) => {
  logger.error(err.message, { stack: err.stack, path: req.path, method: req.method });

  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ success: false, error: 'File too large' });
  }

  const status = err.status || err.statusCode || 500;
  const message = err.message || 'Internal server error';

  if (req.accepts('html')) {
    return res.status(status).render('error', {
      title: 'Error',
      status,
      message: status === 500 && process.env.NODE_ENV === 'production' ? 'Something went wrong' : message,
    });
  }

  res.status(status).json({ success: false, error: message });
};

module.exports = errorHandler;
