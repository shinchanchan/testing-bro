const rateLimit = require('express-rate-limit');
const config = require('../config');

const standard = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.max,
  message: { success: false, error: 'Too many requests, please slow down.' },
  standardHeaders: true,
  legacyHeaders: false,
});

const auth = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: config.rateLimit.authMax,
  message: { success: false, error: 'Too many authentication attempts.' },
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: true,
});

const api = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.apiMax,
  message: { success: false, error: 'API rate limit exceeded.' },
  standardHeaders: true,
  legacyHeaders: false,
});

module.exports = { standard, auth, api };
