const { Client, LocalAuth } = require('whatsapp-web.js');
const QRCode = require('qrcode');
const path = require('path');
const fs = require('fs');
const { encrypt, decrypt } = require('../utils/crypto');
const config = require('../config');
const { sanitizePhone } = require('../utils/helpers');
const { messagingLogger } = require('../utils/logger');

const SESSION_DIR = path.resolve(config.paths.sessions);

const clients = new Map();
const statuses = new Map();
const qrCodes = new Map();

const getUserSessionPath = (userId) => path.join(SESSION_DIR, `${userId}.json`);

const getPuppeteerOptions = () => ({
  headless: config.puppeteer.headless,
  args: config.puppeteer.args,
});

const createClient = (userId) => {
  const sessionFile = getUserSessionPath(userId);
  const authStrategy = new LocalAuth({ dataPath: path.join(SESSION_DIR, `wwebjs_${userId}`) });

  const client = new Client({
    authStrategy,
    puppeteer: getPuppeteerOptions(),
    qrMaxRetries: 3,
  });

  client.on('qr', async (qr) => {
    try {
      const dataUrl = await QRCode.toDataURL(qr);
      qrCodes.set(userId, { qr, dataUrl, at: new Date().toISOString() });
      setStatus(userId, 'qrcode');
      emitToUser(userId, 'whatsapp:qr', { dataUrl });
      messagingLogger.info('QR generated', { userId });
    } catch (err) {
      messagingLogger.error('QR generation failed', { userId, error: err.message });
    }
  });

  client.on('authenticated', () => {
    messagingLogger.info('WhatsApp authenticated', { userId });
  });

  client.on('auth_failure', (msg) => {
    setStatus(userId, 'disconnected');
    messagingLogger.error('WhatsApp auth failure', { userId, error: msg });
  });

  client.on('ready', () => {
    setStatus(userId, 'connected');
    persistSession(userId);
    emitToUser(userId, 'whatsapp:connected', { status: 'connected' });
    messagingLogger.info('WhatsApp ready', { userId });
  });

  client.on('disconnected', async () => {
    setStatus(userId, 'disconnected');
    emitToUser(userId, 'whatsapp:disconnected', { status: 'disconnected' });
    clients.delete(userId);
    messagingLogger.info('WhatsApp disconnected', { userId });
  });

  client.on('loading_screen', () => {
    setStatus(userId, 'connecting');
    emitToUser(userId, 'whatsapp:status', { status: 'connecting' });
  });

  return client;
};

let io = null;
const setSocketIo = (socketIo) => {
  io = socketIo;
};

const emitToUser = (userId, event, payload) => {
  if (io) io.to(`user:${userId}`).emit(event, payload);
};

const setStatus = (userId, status) => {
  statuses.set(userId, { status, at: new Date().toISOString() });
};

const getStatus = (userId) => {
  return statuses.get(userId) || { status: 'disconnected', at: '' };
};

const getQr = (userId) => qrCodes.get(userId) || null;

const persistSession = (userId) => {
  const payload = JSON.stringify({ userId, active: true, at: new Date().toISOString() });
  const encrypted = encrypt(payload);
  fs.writeFileSync(getUserSessionPath(userId), encrypted);
};

const hasPersistedSession = (userId) => fs.existsSync(getUserSessionPath(userId));

const removeSession = (userId) => {
  const file = getUserSessionPath(userId);
  if (fs.existsSync(file)) fs.unlinkSync(file);
  const wwebjsDir = path.join(SESSION_DIR, `wwebjs_${userId}`);
  if (fs.existsSync(wwebjsDir)) fs.rmSync(wwebjsDir, { recursive: true, force: true });
  clients.delete(userId);
  statuses.delete(userId);
  qrCodes.delete(userId);
};

const connect = async (userId) => {
  if (clients.has(userId)) {
    const status = getStatus(userId);
    if (status.status === 'connected') return { status: 'connected' };
  }

  setStatus(userId, 'connecting');
  const client = createClient(userId);
  clients.set(userId, client);

  try {
    await client.initialize();
    return { status: getStatus(userId).status, qr: getQr(userId) };
  } catch (err) {
    setStatus(userId, 'disconnected');
    messagingLogger.error('WhatsApp initialize failed', { userId, error: err.message });
    throw err;
  }
};

const disconnect = async (userId) => {
  const client = clients.get(userId);
  if (client) {
    try {
      await client.destroy();
    } catch (err) {
      messagingLogger.error('WhatsApp destroy error', { userId, error: err.message });
    }
  }
  removeSession(userId);
  return { status: 'disconnected' };
};

const ensureClient = (userId) => {
  const client = clients.get(userId);
  if (!client || getStatus(userId).status !== 'connected') {
    throw new Error('WhatsApp not connected. Please connect first.');
  }
  return client;
};

const sendText = async (userId, phone, message) => {
  const client = ensureClient(userId);
  const to = sanitizePhone(phone);
  if (!to) throw new Error('Invalid phone number');
  const chatId = `${to}@c.us`;
  await client.sendMessage(chatId, message);
  return { to, message };
};

const sendMedia = async (userId, phone, filePath, caption, type) => {
  const client = ensureClient(userId);
  const to = sanitizePhone(phone);
  if (!to) throw new Error('Invalid phone number');
  const chatId = `${to}@c.us`;
  const media = require('whatsapp-web.js').MessageMedia.fromFilePath(filePath);
  await client.sendMessage(chatId, media, { caption: caption || '' });
  return { to, type, caption };
};

const restoreSessions = async () => {
  try {
    const files = fs.readdirSync(SESSION_DIR);
    for (const file of files) {
      if (file.endsWith('.json')) {
        const userId = file.replace('.json', '');
        try {
          await connect(userId);
        } catch (err) {
          messagingLogger.error('Session restore failed', { userId, error: err.message });
        }
      }
    }
  } catch (err) {
    messagingLogger.error('Restore sessions error', { error: err.message });
  }
};

module.exports = {
  setSocketIo,
  connect,
  disconnect,
  sendText,
  sendMedia,
  getStatus,
  getQr,
  hasPersistedSession,
  restoreSessions,
  removeSession,
};
