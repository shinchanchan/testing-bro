const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const csv = require('../utils/csv');
const config = require('../config');
const { generateId, now } = require('../utils/helpers');

const DATA_DIR = path.resolve(config.paths.data);

const ensureDataDir = () => {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  ['sessions', 'tickets', 'webhooks', 'uploads'].forEach((d) => {
    const p = path.join(DATA_DIR, d);
    if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
  });
};

const FILES = {
  users: path.join(DATA_DIR, 'users.csv'),
  payments: path.join(DATA_DIR, 'payments.csv'),
  apiKeys: path.join(DATA_DIR, 'api_keys.csv'),
  webhooks: path.join(DATA_DIR, 'webhooks.csv'),
  messages: path.join(DATA_DIR, 'messages.csv'),
  auditLogs: path.join(DATA_DIR, 'audit_logs.csv'),
};

const HEADERS = {
  users: ['id', 'name', 'email', 'password_hash', 'role', 'status', 'plan', 'plan_type', 'plan_expires_at', 'verified_at', 'created_at'],
  payments: ['id', 'user_id', 'razorpay_order_id', 'razorpay_payment_id', 'signature', 'amount', 'plan', 'plan_type', 'status', 'verified_at', 'created_at'],
  apiKeys: ['id', 'user_id', 'key', 'type', 'status', 'expires_at', 'last_used_at', 'usage_count', 'created_at'],
  webhooks: ['id', 'user_id', 'url', 'secret', 'events', 'status', 'created_at'],
  messages: ['id', 'user_id', 'phone', 'type', 'status', 'media_url', 'caption', 'attempts', 'error', 'sent_at', 'created_at'],
  auditLogs: ['id', 'user_id', 'action', 'ip', 'user_agent', 'meta', 'created_at'],
};

const initFiles = async () => {
  ensureDataDir();
  for (const [key, file] of Object.entries(FILES)) {
    if (!fs.existsSync(file)) {
      fs.writeFileSync(file, HEADERS[key].join(',') + '\n');
    }
  }
};

// Users
const createUser = async ({ name, email, password, role = 'user', status = 'active', plan = 'free' }) => {
  const existing = await csv.findOne(FILES.users, (r) => r.email === email);
  if (existing) throw new Error('Email already registered');
  const hash = await bcrypt.hash(password, config.bcryptRounds);
  const user = {
    id: generateId(),
    name,
    email,
    password_hash: hash,
    role,
    status,
    plan,
    plan_type: '',
    plan_expires_at: '',
    verified_at: '',
    created_at: now(),
  };
  await csv.appendCsv(FILES.users, HEADERS.users, user);
  return sanitizeUser(user);
};

const findUserByEmail = async (email) => {
  const user = await csv.findOne(FILES.users, (r) => r.email === email);
  return user ? sanitizeUser(user) : null;
};

const findUserById = async (id) => {
  const user = await csv.findOne(FILES.users, (r) => r.id === id);
  return user ? sanitizeUser(user) : null;
};

const findUserByIdWithHash = async (id) => {
  return await csv.findOne(FILES.users, (r) => r.id === id);
};

const verifyPassword = async (user, password) => bcrypt.compare(password, user.password_hash);

const updateUser = async (id, updates) => {
  await csv.updateCsv(FILES.users, HEADERS.users, (r) => r.id === id, () => updates);
  return findUserById(id);
};

const listUsers = async () => {
  const rows = await csv.readCsv(FILES.users);
  return rows.map(sanitizeUser);
};

const sanitizeUser = (user) => {
  const { password_hash, ...rest } = user;
  return rest;
};

const seedAdmin = async () => {
  const exists = await findUserByEmail(config.admin.email);
  if (!exists) {
    await createUser({
      name: config.admin.name,
      email: config.admin.email,
      password: config.admin.password,
      role: 'admin',
      status: 'active',
      plan: 'enterprise',
    });
  }
};

// API Keys
const createApiKey = async ({ userId, type = 'live', status = 'active', expiresAt = '' }) => {
  const prefix = type === 'test' ? 'pb_test_' : 'pb_live_';
  const key = `${prefix}${generateId().replace(/-/g, '')}`;
  const row = {
    id: generateId(),
    user_id: userId,
    key,
    type,
    status,
    expires_at: expiresAt,
    last_used_at: '',
    usage_count: '0',
    created_at: now(),
  };
  await csv.appendCsv(FILES.apiKeys, HEADERS.apiKeys, row);
  return row;
};

const findApiKey = async (key) => {
  const rows = await csv.readCsv(FILES.apiKeys);
  return rows.find((r) => r.key === key && r.status === 'active') || null;
};

const listApiKeysByUser = async (userId) => {
  const rows = await csv.readCsv(FILES.apiKeys);
  return rows.filter((r) => r.user_id === userId);
};

const revokeApiKey = async (id, userId) => {
  await csv.updateCsv(FILES.apiKeys, HEADERS.apiKeys, (r) => r.id === id && r.user_id === userId, () => ({ status: 'revoked' }));
};

const incrementApiKeyUsage = async (key) => {
  await csv.updateCsv(FILES.apiKeys, HEADERS.apiKeys, (r) => r.key === key, (r) => ({
    last_used_at: now(),
    usage_count: String(parseInt(r.usage_count || '0', 10) + 1),
  }));
};

// Payments
const createPayment = async (payment) => {
  const row = { id: generateId(), ...payment, created_at: now() };
  await csv.appendCsv(FILES.payments, HEADERS.payments, row);
  return row;
};

const listPayments = async () => csv.readCsv(FILES.payments);

const listPaymentsByUser = async (userId) => {
  const rows = await csv.readCsv(FILES.payments);
  return rows.filter((r) => r.user_id === userId);
};

const updatePaymentStatus = async (id, status) => {
  await csv.updateCsv(FILES.payments, HEADERS.payments, (r) => r.id === id, () => ({ status, verified_at: now() }));
};

// Webhooks
const createWebhook = async (webhook) => {
  const row = { id: generateId(), ...webhook, created_at: now() };
  await csv.appendCsv(FILES.webhooks, HEADERS.webhooks, row);
  return row;
};

const listWebhooksByUser = async (userId) => {
  const rows = await csv.readCsv(FILES.webhooks);
  return rows.filter((r) => r.user_id === userId);
};

const updateWebhook = async (id, userId, updates) => {
  await csv.updateCsv(FILES.webhooks, HEADERS.webhooks, (r) => r.id === id && r.user_id === userId, () => updates);
};

const deleteWebhook = async (id, userId) => {
  const rows = await csv.readCsv(FILES.webhooks);
  const filtered = rows.filter((r) => !(r.id === id && r.user_id === userId));
  await csv.writeCsv(FILES.webhooks, HEADERS.webhooks, filtered);
};

// Messages
const createMessage = async (message) => {
  const row = { id: generateId(), ...message, created_at: now() };
  await csv.appendCsv(FILES.messages, HEADERS.messages, row);
  return row;
};

const updateMessage = async (id, updates) => {
  await csv.updateCsv(FILES.messages, HEADERS.messages, (r) => r.id === id, () => updates);
};

const listMessagesByUser = async (userId, limit = 50) => {
  const rows = await csv.readCsv(FILES.messages);
  return rows.filter((r) => r.user_id === userId).slice(-limit).reverse();
};

const listMessages = async (limit = 200) => {
  const rows = await csv.readCsv(FILES.messages);
  return rows.slice(-limit).reverse();
};

const countDailyMessages = async (userId) => {
  const today = now().slice(0, 10);
  const rows = await csv.readCsv(FILES.messages);
  return rows.filter((r) => r.user_id === userId && r.created_at.startsWith(today)).length;
};

// Audit
const createAuditLog = async (log) => {
  const row = { id: generateId(), ...log, created_at: now() };
  await csv.appendCsv(FILES.auditLogs, HEADERS.auditLogs, row);
};

const listAuditLogs = async (limit = 500) => {
  const rows = await csv.readCsv(FILES.auditLogs);
  return rows.slice(-limit).reverse();
};

module.exports = {
  initFiles,
  seedAdmin,
  createUser,
  findUserByEmail,
  findUserById,
  findUserByIdWithHash,
  verifyPassword,
  updateUser,
  listUsers,
  createApiKey,
  findApiKey,
  listApiKeysByUser,
  revokeApiKey,
  incrementApiKeyUsage,
  createPayment,
  listPayments,
  listPaymentsByUser,
  updatePaymentStatus,
  createWebhook,
  listWebhooksByUser,
  updateWebhook,
  deleteWebhook,
  createMessage,
  updateMessage,
  listMessagesByUser,
  listMessages,
  countDailyMessages,
  createAuditLog,
  listAuditLogs,
  FILES,
  HEADERS,
};
