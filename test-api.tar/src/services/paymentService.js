const Razorpay = require('razorpay');
const crypto = require('crypto');
const config = require('../config');
const dataService = require('./dataService');
const { now } = require('../utils/helpers');
const { paymentLogger } = require('../utils/logger');

let razorpay = null;
try {
  if (config.razorpay.keyId && config.razorpay.keySecret) {
    razorpay = new Razorpay({
      key_id: config.razorpay.keyId,
      key_secret: config.razorpay.keySecret,
    });
  }
} catch (err) {
  paymentLogger.error('Razorpay init failed', { error: err.message });
}

const PLANS = {
  starter: {
    monthly: { amount: 25000, label: 'Starter Monthly' },
    yearly: { amount: 149000, label: 'Starter Yearly' },
  },
};

const getPlanPrice = (plan, type) => {
  return PLANS[plan]?.[type]?.amount ?? 0;
};

const createOrder = async ({ userId, plan, planType }) => {
  if (!razorpay) throw new Error('Razorpay is not configured');
  const amount = getPlanPrice(plan, planType);
  if (!amount) throw new Error('Invalid plan');

  const order = await razorpay.orders.create({
    amount,
    currency: 'INR',
    receipt: `pb_${userId.slice(0, 8)}_${Date.now()}`,
    notes: { userId, plan, planType },
  });

  await dataService.createPayment({
    user_id: userId,
    razorpay_order_id: order.id,
    razorpay_payment_id: '',
    signature: '',
    amount: String(amount / 100),
    plan,
    plan_type: planType,
    status: 'created',
    verified_at: '',
  });

  paymentLogger.info('Order created', { userId, orderId: order.id, plan, planType });
  return { orderId: order.id, amount, currency: 'INR', keyId: config.razorpay.keyId };
};

const verifyPayment = async ({ userId, orderId, paymentId, signature }) => {
  if (!razorpay) throw new Error('Razorpay is not configured');

  const body = `${orderId}|${paymentId}`;
  const expected = crypto.createHmac('sha256', config.razorpay.keySecret).update(body).digest('hex');
  const isValid = expected === signature;

  const paymentRow = await dataService.listPaymentsByUser(userId).then((rows) =>
    rows.find((r) => r.razorpay_order_id === orderId)
  );

  if (!paymentRow) throw new Error('Payment record not found');

  if (isValid) {
    await dataService.updatePaymentStatus(paymentRow.id, 'verified');
    await activatePlan(userId, paymentRow.plan, paymentRow.plan_type);
    paymentLogger.info('Payment verified', { userId, orderId, paymentId });
  } else {
    await dataService.updatePaymentStatus(paymentRow.id, 'failed');
    paymentLogger.warn('Payment verification failed', { userId, orderId });
  }

  return { isValid };
};

const activatePlan = async (userId, plan, planType) => {
  const expires = new Date();
  if (planType === 'yearly') expires.setFullYear(expires.getFullYear() + 1);
  else expires.setMonth(expires.getMonth() + 1);

  await dataService.updateUser(userId, {
    plan,
    plan_type: planType,
    plan_expires_at: expires.toISOString(),
    status: 'active',
  });
};

const manualVerify = async (paymentId) => {
  const payments = await dataService.listPayments();
  const payment = payments.find((p) => p.id === paymentId || p.razorpay_order_id === paymentId);
  if (!payment) throw new Error('Payment not found');
  await dataService.updatePaymentStatus(payment.id, 'verified');
  await activatePlan(payment.user_id, payment.plan, payment.plan_type);
  paymentLogger.info('Payment manually verified', { paymentId: payment.id, admin: true });
};

module.exports = { createOrder, verifyPayment, manualVerify, getPlanPrice, PLANS, razorpay };
