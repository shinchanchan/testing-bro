const path = require('path');
const fs = require('fs');
const dataService = require('./dataService');
const whatsappService = require('./whatsappService');
const webhookService = require('./webhookService');
const config = require('../config');
const { generateId, now, fileHash, sanitizePhone } = require('../utils/helpers');
const { messagingLogger } = require('../utils/logger');

const queues = new Map();
const recentSends = new Map();

const MAX_RETRIES = 3;
const RETRY_DELAYS = [2000, 5000, 15000];

const getQueue = (userId) => {
  if (!queues.has(userId)) queues.set(userId, []);
  return queues.get(userId);
};

const isDuplicateText = (userId, phone, message) => {
  const key = `${userId}:${phone}:${message}:${now().slice(0, 10)}`;
  if (recentSends.has(key)) return true;
  recentSends.set(key, Date.now());
  setTimeout(() => recentSends.delete(key), 60_000);
  return false;
};

const isDuplicateMedia = (userId, filePath) => {
  try {
    const buffer = fs.readFileSync(filePath);
    const hash = fileHash(buffer);
    const key = `${userId}:${hash}`;
    if (recentSends.has(key)) return true;
    recentSends.set(key, Date.now());
    setTimeout(() => recentSends.delete(key), 60_000);
    return false;
  } catch {
    return false;
  }
};

const checkQuota = async (userId) => {
  const user = await dataService.findUserById(userId);
  if (!user) throw new Error('User not found');
  const limit = user.plan === 'starter' ? config.quotas.starterMaxDailyMessages : config.quotas.maxDailyMessages;
  const count = await dataService.countDailyMessages(userId);
  if (count >= limit) throw new Error(`Daily message quota exceeded (${limit})`);
  return { count, limit };
};

const createJob = async ({ userId, phone, type, message, mediaPath, caption }) => {
  await checkQuota(userId);
  const normalized = sanitizePhone(phone);
  if (!normalized) throw new Error('Invalid phone number');

  if (type === 'text' && isDuplicateText(userId, normalized, message)) {
    throw new Error('Duplicate text message detected');
  }
  if (type !== 'text' && mediaPath && isDuplicateMedia(userId, mediaPath)) {
    throw new Error('Duplicate media message detected');
  }

  const persisted = await dataService.createMessage({
    user_id: userId,
    phone: normalized,
    type,
    status: 'pending',
    media_url: mediaPath || '',
    caption: caption || message || '',
    attempts: '0',
    error: '',
    sent_at: '',
  });

  const job = {
    id: persisted.id,
    userId,
    phone: normalized,
    type,
    message,
    mediaPath,
    caption,
    attempts: 0,
    status: 'pending',
  };

  getQueue(userId).push(job);
  processQueue(userId);
  return persisted;
};

const processQueue = async (userId) => {
  const queue = getQueue(userId);
  const pending = queue.find((j) => j.status === 'pending');
  if (!pending) return;

  pending.status = 'processing';
  await dataService.updateMessage(pending.id, { status: 'processing' });

  try {
    if (pending.type === 'text') {
      await whatsappService.sendText(userId, pending.phone, pending.message);
    } else {
      await whatsappService.sendMedia(userId, pending.phone, pending.mediaPath, pending.caption, pending.type);
    }

    pending.status = 'sent';
    await dataService.updateMessage(pending.id, {
      status: 'sent',
      attempts: String(pending.attempts + 1),
      sent_at: now(),
    });

    webhookService.dispatch(userId, 'message.sent', {
      message_id: pending.id,
      phone: pending.phone,
      type: pending.type,
      status: 'sent',
    });

    messagingLogger.info('Message sent', { userId, messageId: pending.id, type: pending.type });
  } catch (err) {
    pending.attempts += 1;
    if (pending.attempts >= MAX_RETRIES) {
      pending.status = 'failed';
      await dataService.updateMessage(pending.id, {
        status: 'failed',
        attempts: String(pending.attempts),
        error: err.message,
      });
      webhookService.dispatch(userId, 'message.failed', {
        message_id: pending.id,
        phone: pending.phone,
        type: pending.type,
        error: err.message,
      });
      messagingLogger.error('Message failed permanently', { userId, messageId: pending.id, error: err.message });
    } else {
      pending.status = 'pending';
      await dataService.updateMessage(pending.id, {
        status: 'pending',
        attempts: String(pending.attempts),
        error: err.message,
      });
      setTimeout(() => processQueue(userId), RETRY_DELAYS[pending.attempts - 1] || 5000);
      messagingLogger.warn('Message retry scheduled', { userId, messageId: pending.id, attempt: pending.attempts });
    }
  }
};

const listByUser = (userId, limit = 50) => dataService.listMessagesByUser(userId, limit);

const getStats = async (userId) => {
  const messages = await dataService.listMessagesByUser(userId, 1000);
  const total = messages.length;
  const sent = messages.filter((m) => m.status === 'sent').length;
  const failed = messages.filter((m) => m.status === 'failed').length;
  const pending = messages.filter((m) => m.status === 'pending' || m.status === 'processing').length;
  const successRate = total ? Math.round((sent / total) * 100) : 0;
  return { total, sent, failed, pending, successRate };
};

module.exports = { createJob, listByUser, getStats, checkQuota };
