const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const http = require('http');
const https = require('https');
const { URL } = require('url');
const dataService = require('./dataService');
const config = require('../config');
const { hmac } = require('../utils/crypto');
const { now } = require('../utils/helpers');
const { logger } = require('../utils/logger');

const logEvent = (userId, webhookId, event, payload, status, response) => {
  const dir = path.resolve(config.paths.webhooks, userId);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `${webhookId}.log`);
  const entry = {
    at: now(),
    event,
    payload,
    status,
    response: response ? String(response).slice(0, 500) : '',
  };
  fs.appendFileSync(file, JSON.stringify(entry) + '\n');
};

const postJson = (url, body, headers) =>
  new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const transport = parsed.protocol === 'https:' ? https : http;
    const req = transport.request(
      {
        hostname: parsed.hostname,
        port: parsed.port,
        path: parsed.pathname + parsed.search,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(body),
          ...headers,
        },
        timeout: 10000,
      },
      (res) => {
        let data = '';
        res.on('data', (chunk) => (data += chunk));
        res.on('end', () => resolve({ status: res.statusCode, data }));
      }
    );
    req.on('error', reject);
    req.on('timeout', () => reject(new Error('Request timeout')));
    req.write(body);
    req.end();
  });

const dispatch = async (userId, event, payload) => {
  const webhooks = await dataService.listWebhooksByUser(userId);
  const active = webhooks.filter((w) => w.status === 'active' && w.events.split(',').includes(event));
  if (!active.length) return;

  for (const webhook of active) {
    const secret = webhook.secret || config.webhook.secretPrefix + crypto.randomBytes(16).toString('hex');
    const body = JSON.stringify({ event, data: payload, created_at: now() });
    const signature = hmac(secret, body);
    const deliveryId = crypto.randomUUID ? crypto.randomUUID() : generateId();

    for (let attempt = 0; attempt < config.webhook.retries; attempt++) {
      try {
        const response = await postJson(webhook.url, body, {
          'X-ParroByte-Event': event,
          'X-ParroByte-Signature': signature,
          'X-ParroByte-Delivery': deliveryId,
        });

        const ok = response.status >= 200 && response.status < 300;
        logEvent(userId, webhook.id, event, payload, ok ? 'delivered' : `failed:${response.status}`, response.data);
        if (ok) break;
      } catch (err) {
        logEvent(userId, webhook.id, event, payload, `error:${err.message}`, '');
        if (attempt === config.webhook.retries - 1) {
          logger.warn('Webhook exhausted retries', { userId, webhookId: webhook.id, event });
        } else {
          await new Promise((r) => setTimeout(r, 2000 * Math.pow(2, attempt)));
        }
      }
    }
  }
};

module.exports = { dispatch, logEvent };
