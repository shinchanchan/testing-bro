require('dotenv').config();

const required = (key, defaultValue) => {
  const value = process.env[key] ?? defaultValue;
  if (value === undefined) {
    if (process.env.NODE_ENV === 'production') {
      throw new Error(`Missing required environment variable: ${key}`);
    }
    console.warn(`[config] Missing env ${key}, using fallback`);
  }
  return value;
};

const asInt = (value, fallback) => {
  const parsed = parseInt(value, 10);
  return Number.isNaN(parsed) ? fallback : parsed;
};

const asBool = (value, fallback = false) => {
  if (value === undefined || value === '') return fallback;
  return value === 'true' || value === '1' || value === 'yes';
};

module.exports = {
  env: required('NODE_ENV', 'development'),
  port: asInt(required('PORT', '3000'), 3000),
  appName: required('APP_NAME', 'ParroByte WhatsApp API'),
  appUrl: required('APP_URL', 'http://localhost:3000'),
  jwtSecret: required('JWT_SECRET', 'dev-jwt-secret-change-me'),
  sessionSecret: required('SESSION_SECRET', 'dev-session-secret-change-me'),
  bcryptRounds: asInt(required('BCRYPT_ROUNDS', '12'), 12),
  admin: {
    email: required('ADMIN_EMAIL', 'admin@parrobyte.local'),
    password: required('ADMIN_PASSWORD', 'admin123'),
    name: required('ADMIN_NAME', 'Admin'),
  },
  razorpay: {
    keyId: required('RAZORPAY_KEY_ID', ''),
    keySecret: required('RAZORPAY_KEY_SECRET', ''),
  },
  puppeteer: {
    headless: asBool(required('PUPPETEER_HEADLESS', 'true'), true),
    args: required('PUPPETEER_ARGS', '--no-sandbox,--disable-setuid-sandbox').split(','),
  },
  rateLimit: {
    windowMs: asInt(required('RATE_LIMIT_WINDOW_MS', '900000'), 900000),
    max: asInt(required('RATE_LIMIT_MAX', '100'), 100),
    authMax: asInt(required('AUTH_RATE_LIMIT_MAX', '10'), 10),
    apiMax: asInt(required('API_RATE_LIMIT_MAX', '200'), 200),
  },
  quotas: {
    maxDailyMessages: asInt(required('MAX_DAILY_MESSAGES', '500'), 500),
    starterMaxDailyMessages: asInt(required('MAX_DAILY_MESSAGES_STARTER', '500'), 500),
  },
  webhook: {
    secretPrefix: required('WEBHOOK_SECRET_PREFIX', 'pbwhsec_'),
    retries: asInt(required('WEBHOOK_RETRIES', '3'), 3),
  },
  uploads: {
    maxFileSizeMb: asInt(required('MAX_FILE_SIZE_MB', '16'), 16),
  },
  paths: {
    data: 'data',
    sessions: 'data/sessions',
    tickets: 'data/tickets',
    webhooks: 'data/webhooks',
    uploads: 'data/uploads',
    logs: 'logs',
  },
};
