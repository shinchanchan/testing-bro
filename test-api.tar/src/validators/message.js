const { body } = require('express-validator');

const sendText = [
  body('phone').trim().notEmpty().withMessage('Phone is required'),
  body('message').trim().notEmpty().isLength({ max: 4096 }).withMessage('Message is required and must be under 4096 chars'),
];

const sendMedia = [
  body('phone').trim().notEmpty().withMessage('Phone is required'),
  body('caption').optional().trim().isLength({ max: 1024 }),
];

module.exports = { sendText, sendMedia };
