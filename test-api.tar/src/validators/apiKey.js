const { body } = require('express-validator');

const create = [body('type').isIn(['live', 'test']).withMessage('Type must be live or test')];

module.exports = { create };
