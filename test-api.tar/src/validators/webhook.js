const { body } = require('express-validator');

const create = [
  body('url').trim().isURL({ require_tld: false }).withMessage('Valid URL required'),
  body('events').trim().notEmpty().withMessage('At least one event is required'),
];

module.exports = { create };
