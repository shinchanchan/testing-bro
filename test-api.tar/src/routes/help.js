const express = require('express');
const router = express.Router();
const controller = require('../controllers/helpController');
const { authenticate } = require('../middleware/auth');

router.get('/', controller.index);
router.get('/page/:slug', controller.page);

router.use(authenticate);
router.get('/tickets', controller.tickets);
router.get('/tickets/new', controller.createTicketView);
router.post('/tickets', controller.createTicket);
router.get('/tickets/:id', controller.ticketDetail);
router.post('/tickets/:id/reply', controller.replyTicket);

module.exports = router;
