const express = require('express');
const router = express.Router();
const config = require('../config');
const paymentService = require('../services/paymentService');

router.get('/', (req, res) => res.render('index', { title: 'ParroByte WhatsApp API', plans: paymentService.PLANS }));
router.get('/docs', (req, res) => res.render('docs', { title: 'API Documentation', appUrl: config.appUrl }));

module.exports = router;
