const express = require('express');
const router = express.Router();
const controller = require('../controllers/authController');
const validators = require('../validators/auth');
const { auth } = require('../middleware/rateLimiters');

router.get('/login', controller.getLogin);
router.get('/signup', controller.getSignup);
router.get('/forgot-password', controller.getForgot);
router.get('/reset-password/:token', controller.getReset);
router.get('/verify-email/:token', controller.verifyEmail);

router.post('/signup', auth, validators.signup, controller.postSignup);
router.post('/login', auth, validators.login, controller.postLogin);
router.post('/logout', controller.logout);
router.post('/forgot-password', auth, validators.forgot, controller.postForgot);
router.post('/reset-password/:token', auth, validators.reset, controller.postReset);

module.exports = router;
