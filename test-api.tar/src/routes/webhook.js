const express = require('express');
const router = express.Router();
const controller = require('../controllers/webhookController');
const { authenticate } = require('../middleware/auth');
const validators = require('../validators/webhook');

router.use(authenticate);

router.get('/', controller.list);
router.post('/', validators.create, controller.create);
router.put('/:id', validators.create, controller.update);
router.delete('/:id', controller.delete);
router.post('/test', controller.test);

module.exports = router;
