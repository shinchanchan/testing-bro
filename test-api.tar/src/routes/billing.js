const express = require('express');
const router = express.Router();
const controller = require('../controllers/billingController');
const { authenticate } = require('../middleware/auth');

router.get('/plans', authenticate, controller.plans);
router.get('/checkout', authenticate, controller.checkout);
router.post('/order', authenticate, controller.createOrder);
router.post('/verify', authenticate, controller.verify);

module.exports = router;
