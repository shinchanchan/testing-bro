const express = require('express');
const router = express.Router();
const controller = require('../controllers/dashboardController');
const { authenticate } = require('../middleware/auth');
const validators = require('../validators/message');
const upload = require('../middleware/upload');

router.use(authenticate);

router.get('/', controller.index);
router.get('/send', controller.send);
router.get('/contacts', controller.contacts);
router.get('/api', controller.api);
router.get('/webhooks', controller.webhooks);
router.get('/billing', controller.billing);
router.get('/help', controller.help);

router.post('/whatsapp/connect', controller.connectWhatsApp);
router.post('/whatsapp/disconnect', controller.disconnectWhatsApp);

router.post('/send/text', validators.sendText, controller.sendText);
router.post('/send/image', upload.single('file'), validators.sendMedia, controller.sendMedia);
router.post('/send/video', upload.single('file'), validators.sendMedia, controller.sendMedia);
router.post('/send/file', upload.single('file'), validators.sendMedia, controller.sendMedia);

module.exports = router;
