const express = require('express');
const router = express.Router();
const controller = require('../controllers/apiController');
const { authenticateApi, authenticateAny } = require('../middleware/auth');
const { api } = require('../middleware/rateLimiters');
const upload = require('../middleware/upload');
const validators = require('../validators/message');

router.use(api);

router.post('/send/text', authenticateApi, validators.sendText, controller.sendText);
router.post('/send/image', authenticateApi, upload.single('file'), validators.sendMedia, controller.sendImage);
router.post('/send/video', authenticateApi, upload.single('file'), validators.sendMedia, controller.sendVideo);
router.post('/send/file', authenticateApi, upload.single('file'), validators.sendMedia, controller.sendFile);

router.get('/keys', authenticateAny, controller.listApiKeys);
router.post('/keys', authenticateAny, require('../validators/apiKey').create, controller.createApiKey);
router.delete('/keys/:id', authenticateAny, controller.revokeApiKey);

router.get('/status', authenticateAny, controller.getStatus);

module.exports = router;
