const express = require('express');
const router = express.Router();
const controller = require('../controllers/adminController');
const { authenticate, requireRole } = require('../middleware/auth');

router.use(authenticate);
router.use(requireRole('admin'));

router.get('/', controller.dashboard);
router.get('/users', controller.users);
router.post('/users/:id', controller.updateUser);
router.get('/payments', controller.payments);
router.post('/payments/:id/verify', controller.verifyPayment);
router.get('/messages', controller.messages);
router.get('/support', controller.support);
router.get('/export/:type', controller.exportCsv);

module.exports = router;
