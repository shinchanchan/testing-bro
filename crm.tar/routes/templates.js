const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const controller = require('../controllers/templatesController');
const { isAuthenticated, requireRole } = require('../middleware/auth');

router.get('/', isAuthenticated, controller.index);
router.get('/create', isAuthenticated, requireRole('superadmin'), controller.create);
router.post('/create', isAuthenticated, requireRole('superadmin'), [
  body('name').trim().notEmpty(),
  body('category').trim().notEmpty(),
  body('type').trim().notEmpty(),
  body('messageContent').trim().notEmpty()
], controller.store);
router.get('/:id/edit', isAuthenticated, requireRole('superadmin'), controller.edit);
router.post('/:id/edit', isAuthenticated, requireRole('superadmin'), [
  body('name').trim().notEmpty(),
  body('category').trim().notEmpty(),
  body('type').trim().notEmpty(),
  body('messageContent').trim().notEmpty()
], controller.update);
router.post('/:id/delete', isAuthenticated, requireRole('superadmin'), controller.destroy);

module.exports = router;
