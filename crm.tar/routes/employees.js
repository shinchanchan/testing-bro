const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const controller = require('../controllers/employeesController');
const { isAuthenticated, requireRole } = require('../middleware/auth');

router.get('/', isAuthenticated, requireRole('superadmin'), controller.index);
router.get('/create', isAuthenticated, requireRole('superadmin'), controller.create);
router.post('/create', isAuthenticated, requireRole('superadmin'), [
  body('employeeId').trim().notEmpty(),
  body('name').trim().notEmpty(),
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 6 }),
  body('role').isIn(['superadmin', 'supervisor'])
], controller.store);
router.get('/performance', isAuthenticated, controller.performance);
router.get('/:id/edit', isAuthenticated, requireRole('superadmin'), controller.edit);
router.post('/:id/edit', isAuthenticated, requireRole('superadmin'), [
  body('employeeId').trim().notEmpty(),
  body('name').trim().notEmpty(),
  body('email').isEmail().normalizeEmail(),
  body('role').isIn(['superadmin', 'supervisor'])
], controller.update);
router.post('/:id/delete', isAuthenticated, requireRole('superadmin'), controller.destroy);

module.exports = router;
