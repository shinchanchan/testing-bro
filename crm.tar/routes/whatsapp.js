const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const controller = require('../controllers/whatsappController');
const { isAuthenticated, requireRole } = require('../middleware/auth');

router.get('/config', isAuthenticated, requireRole('superadmin'), controller.config);
router.post('/config', isAuthenticated, requireRole('superadmin'), controller.updateConfig);
router.get('/config/test', isAuthenticated, requireRole('superadmin'), controller.test);

// New WhatsApp Chat Interface
router.get('/chat', isAuthenticated, controller.chat);
router.get('/messages/:phone', isAuthenticated, controller.getMessages);
router.post('/chat/send', isAuthenticated, controller.sendChatMessage);
router.post('/chat/bulk', isAuthenticated, controller.sendBulkChat);

// Legacy redirects
router.get('/send', isAuthenticated, controller.send);
router.post('/send', isAuthenticated, controller.doSend);
router.get('/bulk', isAuthenticated, controller.bulk);
router.post('/bulk', isAuthenticated, controller.doBulk);

router.get('/logs', isAuthenticated, controller.logs);

module.exports = router;
