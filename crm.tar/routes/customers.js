const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const controller = require('../controllers/customersController');
const { isAuthenticated, requireRole } = require('../middleware/auth');

router.get('/', isAuthenticated, controller.index);
router.get('/export', isAuthenticated, controller.exportCSV);
router.get('/create', isAuthenticated, controller.create);
router.post('/create', isAuthenticated, [
  body('name').trim().notEmpty(),
  body('mobile').trim().notEmpty(),
  body('email').optional().isEmail().normalizeEmail(),
  body('status').optional()
], controller.store);
router.get('/:id', isAuthenticated, controller.show);
router.get('/:id/edit', isAuthenticated, controller.edit);
router.post('/:id/edit', isAuthenticated, [
  body('name').trim().notEmpty(),
  body('mobile').trim().notEmpty()
], controller.update);
router.post('/:id/delete', isAuthenticated, requireRole('superadmin'), controller.destroy);
router.post('/:id/notes', isAuthenticated, controller.addNote);

module.exports = router;
