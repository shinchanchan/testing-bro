const express = require('express');
const router = express.Router();
const controller = require('../controllers/leadsController');
const { isAuthenticated } = require('../middleware/auth');

router.get('/pipeline', isAuthenticated, controller.pipeline);
router.post('/status', isAuthenticated, controller.updateStatus);
router.get('/timeline/:id', isAuthenticated, controller.timeline);

module.exports = router;
