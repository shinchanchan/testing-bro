const express = require('express');
const router = express.Router();
const controller = require('../controllers/settingsController');
const { isAuthenticated, requireRole } = require('../middleware/auth');

router.get('/', isAuthenticated, requireRole('superadmin'), controller.index);
router.post('/', isAuthenticated, requireRole('superadmin'), controller.update);
router.post('/backup', isAuthenticated, requireRole('superadmin'), controller.backup);

module.exports = router;
