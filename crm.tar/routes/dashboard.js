const express = require('express');
const router = express.Router();
const controller = require('../controllers/dashboardController');
const { isAuthenticated } = require('../middleware/auth');

router.get('/', (req, res) => res.redirect('/dashboard'));
router.get('/dashboard', isAuthenticated, controller.index);

module.exports = router;
