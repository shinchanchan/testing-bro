const express = require('express');
const router = express.Router();
const controller = require('../controllers/searchController');
const { isAuthenticated } = require('../middleware/auth');

router.get('/', isAuthenticated, controller.index);

module.exports = router;
