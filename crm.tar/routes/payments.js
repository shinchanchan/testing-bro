const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const controller = require('../controllers/paymentsController');
const { isAuthenticated } = require('../middleware/auth');

router.get('/', isAuthenticated, controller.index);
router.get('/create', isAuthenticated, controller.create);
router.post('/create', isAuthenticated, [
  body('customerId').trim().notEmpty(),
  body('amount').isFloat({ min: 0 }),
  body('dueDate').isISO8601()
], controller.store);
router.get('/:id/edit', isAuthenticated, controller.edit);
router.post('/:id/edit', isAuthenticated, [
  body('customerId').trim().notEmpty(),
  body('amount').isFloat({ min: 0 }),
  body('dueDate').isISO8601()
], controller.update);
router.post('/:id/delete', isAuthenticated, controller.destroy);

module.exports = router;
