const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const controller = require('../controllers/followupsController');
const { isAuthenticated } = require('../middleware/auth');

router.get('/', isAuthenticated, controller.index);
router.get('/create', isAuthenticated, controller.create);
router.post('/create', isAuthenticated, [
  body('customerId').trim().notEmpty(),
  body('scheduledDate').isISO8601(),
  body('messageContent').trim().notEmpty()
], controller.store);
router.post('/:id/complete', isAuthenticated, controller.complete);
router.post('/:id/delete', isAuthenticated, controller.destroy);

module.exports = router;
