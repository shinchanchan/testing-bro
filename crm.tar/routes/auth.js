const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const controller = require('../controllers/authController');
const { redirectIfAuthenticated, isAuthenticated } = require('../middleware/auth');
const { authLimiter } = require('../middleware/security');

router.get('/login', redirectIfAuthenticated, controller.getLogin);
router.post('/login', authLimiter, [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty()
], controller.postLogin);
router.get('/logout', isAuthenticated, controller.logout);
router.get('/profile', isAuthenticated, controller.getProfile);
router.post('/profile', isAuthenticated, [
  body('name').trim().notEmpty(),
  body('mobile').trim().notEmpty(),
  body('currentPassword').optional(),
  body('newPassword').optional().isLength({ min: 6 })
], controller.postProfile);

module.exports = router;
