const moment = require('moment');
const dataService = require('./dataService');

const getDashboardStats = (user = null) => {
  const customers = dataService.getAll('customers.json');
  const followups = dataService.getAll('followups.json');
  const employees = dataService.getAll('employees.json');
  const payments = dataService.getAll('payments.json');

  let filteredCustomers = customers;
  if (user && user.role === 'supervisor') {
    filteredCustomers = customers.filter(c => c.assignedEmployee === user.id);
  }

  const today = moment().startOf('day');
  const todayFollowups = followups.filter(f =>
    moment(f.scheduledDate).isSame(today, 'day') &&
    (user ? f.assignedTo === user.id : true)
  );

  const pendingFollowups = followups.filter(f =>
    f.status === 'scheduled' &&
    moment(f.scheduledDate).isSameOrBefore(today, 'day') &&
    (user ? f.assignedTo === user.id : true)
  );

  const converted = filteredCustomers.filter(c => c.status === 'Converted');
  const lost = filteredCustomers.filter(c => c.status === 'Lost');

  const monthlyRevenue = payments
    .filter(p => moment(p.paidDate).isSame(today, 'month'))
    .reduce((sum, p) => sum + (parseFloat(p.amount) || 0), 0);

  const activeCustomers = filteredCustomers.filter(c => c.status === 'Converted').length;

  const completedFollowups = followups.filter(f => f.status === 'completed').length;
  const totalFollowups = followups.length || 1;
  const successRate = Math.round((completedFollowups / totalFollowups) * 100);

  return {
    totalLeads: filteredCustomers.length,
    todayFollowups: todayFollowups.length,
    pendingFollowups: pendingFollowups.length,
    convertedLeads: converted.length,
    monthlyRevenue,
    activeCustomers,
    employeeCount: employees.length,
    followUpSuccessRate: successRate,
    newLeads: filteredCustomers.filter(c => c.status === 'New Lead').length,
    connected: filteredCustomers.filter(c => c.status === 'Connected').length,
    followUpOngoing: filteredCustomers.filter(c => c.status === 'Follow-up Ongoing').length,
    lostLeads: lost.length
  };
};

const getLeadPipelineData = (user = null) => {
  const customers = dataService.getAll('customers.json');
  const statuses = [
    'New Lead',
    'Discussed',
    'Connected',
    'Follow-up Ongoing',
    'Proposal Sent',
    'Negotiation',
    'Converted',
    'Lost'
  ];

  let filteredCustomers = customers;
  if (user && user.role === 'supervisor') {
    filteredCustomers = customers.filter(c => c.assignedEmployee === user.id);
  }

  return statuses.map(status => ({
    status,
    count: filteredCustomers.filter(c => c.status === status).length,
    customers: filteredCustomers.filter(c => c.status === status)
  }));
};

const getEmployeePerformance = () => {
  const employees = dataService.getAll('employees.json');
  const customers = dataService.getAll('customers.json');

  return employees.map(emp => {
    const assigned = customers.filter(c => c.assignedEmployee === emp.id);
    return {
      ...emp,
      passwordHash: undefined,
      totalAssigned: assigned.length,
      converted: assigned.filter(c => c.status === 'Converted').length,
      lost: assigned.filter(c => c.status === 'Lost').length,
      inProgress: assigned.filter(c =>
        !['Converted', 'Lost', 'New Lead'].includes(c.status)
      ).length,
      revenue: assigned
        .filter(c => c.status === 'Converted')
        .reduce((sum, c) => sum + (parseFloat(c.subscriptionAmount) || 0), 0)
    };
  });
};

const getMonthlySales = () => {
  const payments = dataService.getAll('payments.json');
  const months = {};
  payments.forEach(p => {
    const key = moment(p.paidDate).format('MMM YYYY');
    months[key] = (months[key] || 0) + (parseFloat(p.amount) || 0);
  });
  return Object.entries(months).map(([month, amount]) => ({ month, amount }));
};

module.exports = {
  getDashboardStats,
  getLeadPipelineData,
  getEmployeePerformance,
  getMonthlySales
};
