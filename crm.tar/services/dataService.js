const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const DATA_DIR = path.join(__dirname, '..', 'data');
const CONFIG_DIR = path.join(__dirname, '..', 'config');
const BACKUP_DIR = path.join(__dirname, '..', 'backups');

const ensureDir = (dir) => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
};

ensureDir(DATA_DIR);
ensureDir(CONFIG_DIR);
ensureDir(BACKUP_DIR);

const filePath = (name, isConfig = false) => path.join(isConfig ? CONFIG_DIR : DATA_DIR, name);

const readFile = (filename, isConfig = false, defaultValue = []) => {
  const fp = filePath(filename, isConfig);
  try {
    if (!fs.existsSync(fp)) {
      writeFile(filename, defaultValue, isConfig);
      return defaultValue;
    }
    const content = fs.readFileSync(fp, 'utf8');
    return JSON.parse(content);
  } catch (err) {
    console.error(`Error reading ${filename}:`, err.message);
    // Attempt recovery from backup
    const backupFiles = fs.readdirSync(BACKUP_DIR)
      .filter(f => f.endsWith(`_${filename}`))
      .sort()
      .reverse();
    for (const backup of backupFiles) {
      try {
        const recovered = JSON.parse(fs.readFileSync(path.join(BACKUP_DIR, backup), 'utf8'));
        writeFile(filename, recovered, isConfig);
        return recovered;
      } catch (e) {
        continue;
      }
    }
    return defaultValue;
  }
};

const writeFile = (filename, data, isConfig = false) => {
  const fp = filePath(filename, isConfig);
  fs.writeFileSync(fp, JSON.stringify(data, null, 2), 'utf8');
};

const backup = (filename, isConfig = false) => {
  const fp = filePath(filename, isConfig);
  if (!fs.existsSync(fp)) return;
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupName = `${timestamp}_${filename}`;
  fs.copyFileSync(fp, path.join(BACKUP_DIR, backupName));
};

const backupAll = () => {
  const files = [
    { name: 'customers.json' },
    { name: 'employees.json' },
    { name: 'templates.json' },
    { name: 'followups.json' },
    { name: 'payments.json' },
    { name: 'logs.json' },
    { name: 'messages.json' },
    { name: 'settings.json' },
    { name: 'whatsapp.json', isConfig: true }
  ];
  files.forEach(f => backup(f.name, f.isConfig));
};

// Generic CRUD helpers
const getAll = (filename, isConfig = false, defaultValue = []) => readFile(filename, isConfig, defaultValue);

const getById = (filename, id, isConfig = false, defaultValue = []) => {
  const items = getAll(filename, isConfig, defaultValue);
  return items.find(item => item.id === id);
};

const create = (filename, data, isConfig = false, defaultValue = []) => {
  const items = getAll(filename, isConfig, defaultValue);
  const newItem = { ...data, id: data.id || uuidv4(), createdAt: data.createdAt || new Date().toISOString() };
  items.push(newItem);
  backup(filename, isConfig);
  writeFile(filename, items, isConfig);
  return newItem;
};

const update = (filename, id, updates, isConfig = false, defaultValue = []) => {
  const items = getAll(filename, isConfig, defaultValue);
  const index = items.findIndex(item => item.id === id);
  if (index === -1) return null;
  items[index] = { ...items[index], ...updates, updatedAt: new Date().toISOString() };
  backup(filename, isConfig);
  writeFile(filename, items, isConfig);
  return items[index];
};

const remove = (filename, id, isConfig = false, defaultValue = []) => {
  const items = getAll(filename, isConfig, defaultValue);
  const index = items.findIndex(item => item.id === id);
  if (index === -1) return false;
  items.splice(index, 1);
  backup(filename, isConfig);
  writeFile(filename, items, isConfig);
  return true;
};

const query = (filename, predicate, isConfig = false, defaultValue = []) => {
  const items = getAll(filename, isConfig, defaultValue);
  return items.filter(predicate);
};

// Settings helper
const getSettings = () => readFile('settings.json', false, {});
const updateSettings = (updates) => {
  const settings = getSettings();
  Object.assign(settings, updates);
  backup('settings.json');
  writeFile('settings.json', settings);
  return settings;
};

// Logging helper
const logActivity = (action, details, userId = null) => {
  create('logs.json', {
    action,
    details,
    userId,
    timestamp: new Date().toISOString()
  });
};

module.exports = {
  readFile,
  writeFile,
  backup,
  backupAll,
  getAll,
  getById,
  create,
  update,
  remove,
  query,
  getSettings,
  updateSettings,
  logActivity
};
