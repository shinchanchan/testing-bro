const moment = require('moment');
const dataService = require('./dataService');
const whatsappService = require('./whatsappService');

const getActiveSchedule = () => {
  const settings = dataService.getSettings();
  return settings.followUpSchedule || [];
};

const getCustomersNeedingFollowUp = () => {
  const customers = dataService.getAll('customers.json');
  const followups = dataService.getAll('followups.json');
  const settings = dataService.getSettings();
  const schedule = settings.followUpSchedule || [];
  const now = moment();

  const pending = [];

  customers.forEach(customer => {
    const createdAt = moment(customer.createdAt);
    const customerFollowups = followups.filter(f => f.customerId === customer.id);
    const lastFollowUp = customerFollowups.length ? moment(customerFollowups[customerFollowups.length - 1].scheduledDate) : null;

    schedule.forEach(rule => {
      if (!rule.enabled) return;
      const scheduledDate = createdAt.clone().add(rule.day, 'days').startOf('day');
      const isDone = customerFollowups.some(f =>
        f.ruleDay === rule.day && f.status === 'completed'
      );
      const isScheduled = customerFollowups.some(f =>
        f.ruleDay === rule.day && f.status === 'scheduled'
      );

      if (!isDone && !isScheduled && scheduledDate.isSameOrBefore(now, 'day')) {
        pending.push({
          customer,
          rule,
          scheduledDate: scheduledDate.toISOString(),
          type: 'followup'
        });
      }
    });

    // Payment reminders
    if (customer.renewalDate) {
      const renewal = moment(customer.renewalDate);
      const reminders = settings.paymentReminders || [];
      reminders.forEach(reminder => {
        const reminderDate = renewal.clone().subtract(reminder.daysBefore, 'days').startOf('day');
        if (reminderDate.isSame(now, 'day') && reminder.enabled) {
          const exists = followups.some(f =>
            f.customerId === customer.id &&
            f.type === 'payment_reminder' &&
            moment(f.scheduledDate).isSame(reminderDate, 'day') &&
            f.status !== 'completed'
          );
          if (!exists) {
            pending.push({
              customer,
              rule: { name: `Payment Reminder - ${reminder.daysBefore} days`, day: reminder.daysBefore },
              scheduledDate: reminderDate.toISOString(),
              type: 'payment_reminder'
            });
          }
        }
      });
    }
  });

  return pending;
};

const createFollowUp = (data) => {
  return dataService.create('followups.json', {
    ...data,
    status: 'scheduled',
    createdAt: new Date().toISOString()
  });
};

const runAutomation = async () => {
  const pending = getCustomersNeedingFollowUp();
  const templates = dataService.getAll('templates.json');

  for (const item of pending) {
    const template = templates.find(t =>
      t.category === (item.type === 'payment_reminder' ? 'Payment Reminder' : 'Follow-up') &&
      t.name.toLowerCase().includes(item.rule.name.toLowerCase())
    ) || templates.find(t => t.category === 'Follow-up');

    const followUp = createFollowUp({
      customerId: item.customer.id,
      customerName: item.customer.name,
      ruleDay: item.rule.day,
      ruleName: item.rule.name,
      type: item.type,
      scheduledDate: item.scheduledDate,
      messageContent: template ? template.messageContent : `Follow-up: ${item.rule.name}`,
      templateId: template ? template.id : null,
      status: 'scheduled'
    });

    // Auto-send if WhatsApp enabled and customer has WhatsApp number
    if (item.customer.whatsappNumber && template) {
      const result = await whatsappService.sendTemplate(item.customer.whatsappNumber, template);
      if (result.success) {
        dataService.update('followups.json', followUp.id, {
          status: 'completed',
          sentAt: new Date().toISOString(),
          messageId: result.data.messages?.[0]?.id
        });
        dataService.logActivity('followup_sent', {
          customerId: item.customer.id,
          followUpId: followUp.id,
          ruleName: item.rule.name
        });
      }
    }
  }

  dataService.logActivity('automation_run', { count: pending.length });
  return pending.length;
};

module.exports = {
  getCustomersNeedingFollowUp,
  createFollowUp,
  runAutomation
};
