const moment = require('moment');
const dataService = require('./dataService');

const getNotifications = (user = null) => {
  const customers = dataService.getAll('customers.json');
  const followups = dataService.getAll('followups.json');
  const payments = dataService.getAll('payments.json');
  const today = moment().startOf('day');

  let userFilter = () => true;
  if (user && user.role === 'supervisor') {
    userFilter = (c) => c.assignedEmployee === user.id;
  }

  const notifications = [];

  // Today's follow-ups
  followups
    .filter(f => f.status === 'scheduled' && moment(f.scheduledDate).isSame(today, 'day'))
    .forEach(f => {
      const customer = customers.find(c => c.id === f.customerId);
      if (customer && userFilter(customer)) {
        notifications.push({
          type: 'followup',
          priority: 'normal',
          title: 'Today\'s Follow-up',
          message: `Follow-up with ${customer.name}`,
          link: `/followups`,
          time: f.scheduledDate
        });
      }
    });

  // Missed follow-ups
  followups
    .filter(f => f.status === 'scheduled' && moment(f.scheduledDate).isBefore(today, 'day'))
    .forEach(f => {
      const customer = customers.find(c => c.id === f.customerId);
      if (customer && userFilter(customer)) {
        notifications.push({
          type: 'missed',
          priority: 'high',
          title: 'Missed Follow-up',
          message: `Missed follow-up with ${customer.name}`,
          link: `/followups`,
          time: f.scheduledDate
        });
      }
    });

  // Due payments
  payments.forEach(p => {
    const customer = customers.find(c => c.id === p.customerId);
    if (!customer || !userFilter(customer)) return;
    const dueDate = moment(p.dueDate);
    const diff = dueDate.diff(today, 'days');
    if (diff <= 3 && diff >= -1 && p.status !== 'paid') {
      notifications.push({
        type: 'payment',
        priority: diff <= 0 ? 'high' : 'normal',
        title: 'Payment Due',
        message: `${customer.name} - ${p.amount} due ${dueDate.fromNow()}`,
        link: `/payments`,
        time: p.dueDate
      });
    }
  });

  // New leads today
  customers
    .filter(c => moment(c.createdAt).isSame(today, 'day') && userFilter(c))
    .forEach(c => {
      notifications.push({
        type: 'lead',
        priority: 'normal',
        title: 'New Lead',
        message: `${c.name} from ${c.businessName || 'Unknown'}`,
        link: `/customers/${c.id}`,
        time: c.createdAt
      });
    });

  return notifications.sort((a, b) => new Date(b.time) - new Date(a.time)).slice(0, 20);
};

const getCounts = (user = null) => {
  const notifications = getNotifications(user);
  return {
    total: notifications.length,
    high: notifications.filter(n => n.priority === 'high').length
  };
};

module.exports = {
  getNotifications,
  getCounts
};
