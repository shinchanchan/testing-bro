const fs = require('fs');
const path = require('path');
const dataService = require('./dataService');

const getConfig = () => dataService.readFile('whatsapp.json', true, {});

const buildApiUrl = (phoneNumberId, version) => {
  return `https://graph.facebook.com/${version}/${phoneNumberId}/messages`;
};

const sendMessage = async (to, messageData, type = 'text') => {
  const config = getConfig();
  if (!config.enabled || !config.accessToken || !config.phoneNumberId) {
    return { success: false, error: 'WhatsApp API not configured or disabled' };
  }

  const payload = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: formatPhone(to)
  };

  if (type === 'text') {
    payload.type = 'text';
    payload.text = { preview_url: true, body: messageData.body };
  } else if (type === 'image') {
    payload.type = 'image';
    payload.image = { link: messageData.mediaUrl, caption: messageData.caption || '' };
  } else if (type === 'video') {
    payload.type = 'video';
    payload.video = { link: messageData.mediaUrl, caption: messageData.caption || '' };
  } else if (type === 'document') {
    payload.type = 'document';
    payload.document = { link: messageData.mediaUrl, caption: messageData.caption || '', filename: messageData.filename || 'document.pdf' };
  } else if (type === 'button') {
    payload.type = 'interactive';
    payload.interactive = {
      type: 'button',
      body: { text: messageData.body },
      action: {
        buttons: [
          { type: 'reply', reply: { id: 'btn_1', title: messageData.buttonText } }
        ]
      }
    };
  } else if (type === 'url_button') {
    payload.type = 'interactive';
    payload.interactive = {
      type: 'cta_url',
      body: { text: messageData.body },
      action: {
        name: 'cta_url',
        parameters: {
          display_text: messageData.buttonText,
          url: messageData.buttonUrl
        }
      }
    };
  }

  try {
    const response = await fetch(buildApiUrl(config.phoneNumberId, config.apiVersion || 'v18.0'), {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${config.accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error?.message || 'Unknown error');

    const messageRecord = {
      to: formatPhone(to),
      type,
      body: messageData.body,
      mediaUrl: messageData.mediaUrl,
      buttonText: messageData.buttonText,
      buttonUrl: messageData.buttonUrl,
      filename: messageData.filename,
      direction: 'outgoing',
      status: 'sent',
      messageId: result.messages?.[0]?.id,
      sentAt: new Date().toISOString()
    };

    dataService.create('messages.json', messageRecord);
    dataService.logActivity('whatsapp_message_sent', {
      to,
      type,
      messageId: result.messages?.[0]?.id
    });

    return { success: true, data: result };
  } catch (error) {
    console.error('WhatsApp send error:', error.message);
    return { success: false, error: error.message };
  }
};

const formatPhone = (phone) => {
  return phone.replace(/\D/g, '').replace(/^0+/, '');
};

const sendTemplate = async (to, template) => {
  if (!template) return { success: false, error: 'Template not found' };

  const messageData = {
    body: template.messageContent,
    mediaUrl: template.mediaUrl,
    caption: template.messageContent,
    buttonText: template.buttonText,
    buttonUrl: template.buttonUrl,
    filename: template.filename
  };

  return sendMessage(to, messageData, template.type);
};

const bulkSend = async (recipients, templateId) => {
  const templates = dataService.getAll('templates.json');
  const template = templates.find(t => t.id === templateId);
  const results = [];
  for (const recipient of recipients) {
    const result = await sendTemplate(recipient, template);
    results.push({ recipient, ...result });
  }
  return results;
};

const getMessages = (phone = null) => {
  const messages = dataService.getAll('messages.json');
  if (!phone) return messages.sort((a, b) => new Date(a.sentAt) - new Date(b.sentAt));
  return messages
    .filter(m => m.to === formatPhone(phone))
    .sort((a, b) => new Date(a.sentAt) - new Date(b.sentAt));
};

const testConnection = async () => {
  const config = getConfig();
  if (!config.enabled || !config.accessToken) {
    return { success: false, error: 'WhatsApp API not configured' };
  }
  try {
    const url = `https://graph.facebook.com/${config.apiVersion || 'v18.0'}/${config.phoneNumberId}`;
    const response = await fetch(url, {
      headers: { 'Authorization': `Bearer ${config.accessToken}` }
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error?.message || 'Connection failed');
    return { success: true, data: result };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

module.exports = {
  sendMessage,
  sendTemplate,
  bulkSend,
  getMessages,
  formatPhone,
  testConnection,
  getConfig
};
