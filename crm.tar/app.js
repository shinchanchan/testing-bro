require('dotenv').config();
const express = require('express');
const path = require('path');
const session = require('express-session');
const flash = require('connect-flash');
const cookieParser = require('cookie-parser');
const morgan = require('morgan');
const cron = require('node-cron');
const expressLayouts = require('express-ejs-layouts');

const { securityHeaders, apiLimiter, authLimiter, csrfProtection, setCsrfToken } = require('./middleware/security');
const { loadUser } = require('./middleware/auth');
const dataService = require('./services/dataService');
const automationService = require('./services/automationService');

const app = express();
const PORT = process.env.PORT || 3000;

// View engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(expressLayouts);
app.set('layout', 'layouts/main');

// Middleware
app.use(securityHeaders);
app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Session
app.use(session({
  secret: process.env.SESSION_SECRET || 'whatsapp-crm-secret-key-change-in-production',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000
  }
}));

// Flash messages
app.use(flash());

// CSRF Protection (skip for file uploads and API webhooks)
app.use((req, res, next) => {
  if (req.path.startsWith('/uploads') || req.path.startsWith('/api/webhook')) return next();
  csrfProtection(req, res, next);
});
app.use(setCsrfToken);

// Load user and globals
app.use(loadUser);
app.use((req, res, next) => {
  res.locals.success = req.flash('success');
  res.locals.error = req.flash('error');
  res.locals.settings = dataService.getSettings();
  next();
});

// Routes
app.use('/', require('./routes/auth'));
app.use('/', require('./routes/dashboard'));
app.use('/customers', require('./routes/customers'));
app.use('/leads', require('./routes/leads'));
app.use('/employees', require('./routes/employees'));
app.use('/templates', require('./routes/templates'));
app.use('/followups', require('./routes/followups'));
app.use('/payments', require('./routes/payments'));
app.use('/reports', require('./routes/reports'));
app.use('/whatsapp', require('./routes/whatsapp'));
app.use('/search', require('./routes/search'));
app.use('/settings', require('./routes/settings'));
app.use('/notifications', require('./routes/notifications'));

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// 404
app.use((req, res) => {
  res.status(404).render('error', { title: 'Page Not Found', message: 'The page you are looking for does not exist.' });
});

// Error handler
app.use((err, req, res, next) => {
  if (err.code === 'EBADCSRFTOKEN') {
    req.flash('error', 'Invalid CSRF token. Please try again.');
    return res.redirect(req.session.user ? '/dashboard' : '/login');
  }
  console.error(err.stack);
  res.status(500).render('error', { title: 'Server Error', message: err.message || 'Something went wrong' });
});

// Scheduled tasks
if (process.env.NODE_ENV !== 'test') {
  // Backup data daily
  cron.schedule('0 2 * * *', () => {
    dataService.backupAll();
    console.log('Daily backup completed');
  });

  // Automation engine every hour
  cron.schedule('0 * * * *', () => {
    automationService.runAutomation();
  });
}

app.listen(PORT, () => {
  console.log(`WhatsApp CRM running on http://localhost:${PORT}`);
});

module.exports = app;
