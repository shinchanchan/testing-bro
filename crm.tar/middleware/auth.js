const bcrypt = require('bcryptjs');
const dataService = require('../services/dataService');

const isAuthenticated = (req, res, next) => {
  if (req.session && req.session.user) return next();
  req.flash('error', 'Please login to continue');
  res.redirect('/login');
};

const redirectIfAuthenticated = (req, res, next) => {
  if (req.session && req.session.user) return res.redirect('/dashboard');
  next();
};

const requireRole = (...roles) => {
  return (req, res, next) => {
    if (!req.session || !req.session.user) {
      req.flash('error', 'Please login to continue');
      return res.redirect('/login');
    }
    if (!roles.includes(req.session.user.role)) {
      req.flash('error', 'You do not have permission to access this page');
      return res.redirect('/dashboard');
    }
    next();
  };
};

const loadUser = (req, res, next) => {
  res.locals.user = req.session.user || null;
  res.locals.currentPath = req.path;
  next();
};

const loginUser = async (email, password) => {
  const employees = dataService.getAll('employees.json');
  const user = employees.find(e => e.email.toLowerCase() === email.toLowerCase() && e.isActive !== false);
  if (!user) return null;
  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) return null;
  const { passwordHash, ...safeUser } = user;
  return safeUser;
};

module.exports = {
  isAuthenticated,
  redirectIfAuthenticated,
  requireRole,
  loadUser,
  loginUser
};
