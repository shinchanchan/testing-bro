const dataService = require('../services/dataService');

exports.index = (req, res) => {
  const { q } = req.query;
  const user = req.session.user;
  let results = { customers: [], employees: [], templates: [] };

  if (q && q.trim()) {
    const query = q.toLowerCase();

    let customers = dataService.getAll('customers.json');
    if (user.role === 'supervisor') {
      customers = customers.filter(c => c.assignedEmployee === user.id);
    }
    results.customers = customers.filter(c =>
      c.name.toLowerCase().includes(query) ||
      (c.businessName && c.businessName.toLowerCase().includes(query)) ||
      (c.mobile && c.mobile.includes(query))
    );

    if (user.role === 'superadmin') {
      results.employees = dataService.getAll('employees.json').filter(e =>
        e.name.toLowerCase().includes(query) ||
        e.email.toLowerCase().includes(query)
      );
    }

    results.templates = dataService.getAll('templates.json').filter(t =>
      t.name.toLowerCase().includes(query) ||
      t.category.toLowerCase().includes(query)
    );
  }

  res.render('search/index', { title: 'Search', query: q, results });
};
