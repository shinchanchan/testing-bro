const dataService = require('../services/dataService');

exports.index = (req, res) => {
  const settings = dataService.getSettings();
  res.render('settings/index', { title: 'Settings', settings, errors: [] });
};

exports.update = (req, res) => {
  const settings = dataService.getSettings();

  settings.companyName = req.body.companyName;
  settings.currency = req.body.currency;
  settings.backupEnabled = req.body.backupEnabled === 'on';
  settings.backupIntervalHours = parseInt(req.body.backupIntervalHours) || 24;

  // Update follow-up schedule
  settings.followUpSchedule = (req.body.followUpDay || []).map((day, i) => ({
    day: parseInt(day),
    name: req.body.followUpName[i] || '',
    enabled: req.body.followUpEnabled && req.body.followUpEnabled[i] === 'on'
  }));

  dataService.updateSettings(settings);
  dataService.logActivity('settings_updated', {}, req.session.user.id);
  req.flash('success', 'Settings updated successfully');
  res.redirect('/settings');
};

exports.backup = (req, res) => {
  dataService.backupAll();
  dataService.logActivity('manual_backup', {}, req.session.user.id);
  req.flash('success', 'Backup completed successfully');
  res.redirect('/settings');
};
