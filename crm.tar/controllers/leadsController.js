const dataService = require('../services/dataService');
const reportService = require('../services/reportService');
const moment = require('moment');

const statuses = [
  'New Lead',
  'Discussed',
  'Connected',
  'Follow-up Ongoing',
  'Proposal Sent',
  'Negotiation',
  'Converted',
  'Lost'
];

exports.pipeline = (req, res) => {
  const user = req.session.user;
  const pipeline = reportService.getLeadPipelineData(user);
  res.render('leads/pipeline', { title: 'Lead Pipeline', pipeline, statuses });
};

exports.updateStatus = (req, res) => {
  const { id, status } = req.body;
  const customer = dataService.getById('customers.json', id);
  if (!customer) return res.status(404).json({ success: false, error: 'Customer not found' });

  if (user.role === 'supervisor' && customer.assignedEmployee !== user.id) {
    return res.status(403).json({ success: false, error: 'Access denied' });
  }

  const oldStatus = customer.status;
  dataService.update('customers.json', id, { status });

  dataService.logActivity('lead_status_changed', {
    customerId: id,
    oldStatus,
    newStatus: status
  }, req.session.user.id);

  res.json({ success: true });
};

exports.timeline = (req, res) => {
  const customer = dataService.getById('customers.json', req.params.id);
  if (!customer) return res.status(404).render('error', { title: 'Not Found', message: 'Customer not found' });

  const logs = dataService.query('logs.json', l => l.details?.customerId === req.params.id)
    .sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));

  const timeline = [
    { type: 'created', title: 'Lead Created', date: customer.createdAt, description: `Lead created for ${customer.name}` },
    ...logs.map(l => ({
      type: l.action,
      title: l.action.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
      date: l.timestamp,
      description: JSON.stringify(l.details)
    }))
  ];

  res.render('leads/timeline', { title: 'Lead Timeline', customer, timeline, moment });
};
