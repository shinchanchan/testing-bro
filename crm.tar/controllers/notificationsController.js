const notificationService = require('../services/notificationService');

exports.index = (req, res) => {
  const notifications = notificationService.getNotifications(req.session.user);
  const counts = notificationService.getCounts(req.session.user);
  res.json({ notifications, counts });
};
