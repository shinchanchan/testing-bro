const { validationResult } = require('express-validator');
const dataService = require('../services/dataService');
const moment = require('moment');

const canAccessCustomer = (user, customer) => {
  if (user.role === 'superadmin') return true;
  return customer.assignedEmployee === user.id;
};

exports.index = (req, res) => {
  const user = req.session.user;
  let customers = dataService.getAll('customers.json');
  if (user.role === 'supervisor') {
    customers = customers.filter(c => c.assignedEmployee === user.id);
  }

  const { status, employee, search } = req.query;
  if (status) customers = customers.filter(c => c.status === status);
  if (employee && user.role === 'superadmin') customers = customers.filter(c => c.assignedEmployee === employee);
  if (search) {
    const q = search.toLowerCase();
    customers = customers.filter(c =>
      c.name.toLowerCase().includes(q) ||
      (c.businessName && c.businessName.toLowerCase().includes(q)) ||
      (c.mobile && c.mobile.includes(q)) ||
      (c.email && c.email.toLowerCase().includes(q))
    );
  }

  const employees = dataService.getAll('employees.json').map(e => ({ id: e.id, name: e.name }));

  res.render('customers/index', {
    title: 'Customers',
    customers: customers.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)),
    employees,
    filters: { status, employee, search },
    moment
  });
};

exports.show = (req, res) => {
  const customer = dataService.getById('customers.json', req.params.id);
  if (!customer) return res.status(404).render('error', { title: 'Not Found', message: 'Customer not found' });
  if (!canAccessCustomer(req.session.user, customer)) {
    req.flash('error', 'Access denied');
    return res.redirect('/customers');
  }

  const employees = dataService.getAll('employees.json');
  const followups = dataService.query('followups.json', f => f.customerId === customer.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const logs = dataService.query('logs.json', l => l.details?.customerId === customer.id)
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

  res.render('customers/show', {
    title: customer.name,
    customer,
    employees,
    followups,
    logs,
    moment
  });
};

exports.create = (req, res) => {
  const employees = dataService.getAll('employees.json');
  res.render('customers/create', { title: 'Add Customer', errors: [], employees, data: {} });
};

exports.store = (req, res) => {
  const errors = validationResult(req);
  const employees = dataService.getAll('employees.json');
  if (!errors.isEmpty()) {
    return res.render('customers/create', { title: 'Add Customer', errors: errors.array(), employees, data: req.body });
  }

  const customer = {
    name: req.body.name,
    businessName: req.body.businessName,
    mobile: req.body.mobile,
    secondaryMobile: req.body.secondaryMobile,
    whatsappNumber: req.body.whatsappNumber,
    email: req.body.email,
    address: req.body.address,
    city: req.body.city,
    state: req.body.state,
    notes: req.body.notes,
    assignedEmployee: req.body.assignedEmployee || req.session.user.id,
    status: req.body.status || 'New Lead',
    subscriptionPlan: req.body.subscriptionPlan,
    subscriptionAmount: parseFloat(req.body.subscriptionAmount) || 0,
    renewalDate: req.body.renewalDate || null,
    createdAt: new Date().toISOString()
  };

  const newCustomer = dataService.create('customers.json', customer);
  dataService.logActivity('customer_created', { customerId: newCustomer.id, name: newCustomer.name }, req.session.user.id);
  req.flash('success', 'Customer added successfully');
  res.redirect('/customers');
};

exports.edit = (req, res) => {
  const customer = dataService.getById('customers.json', req.params.id);
  if (!customer) return res.status(404).render('error', { title: 'Not Found', message: 'Customer not found' });
  const employees = dataService.getAll('employees.json');
  res.render('customers/edit', { title: 'Edit Customer', errors: [], customer, employees });
};

exports.update = (req, res) => {
  const errors = validationResult(req);
  const customer = dataService.getById('customers.json', req.params.id);
  if (!customer) return res.status(404).render('error', { title: 'Not Found', message: 'Customer not found' });

  const employees = dataService.getAll('employees.json');
  if (!errors.isEmpty()) {
    return res.render('customers/edit', { title: 'Edit Customer', errors: errors.array(), customer: { ...customer, ...req.body }, employees });
  }

  const oldStatus = customer.status;
  const updates = {
    name: req.body.name,
    businessName: req.body.businessName,
    mobile: req.body.mobile,
    secondaryMobile: req.body.secondaryMobile,
    whatsappNumber: req.body.whatsappNumber,
    email: req.body.email,
    address: req.body.address,
    city: req.body.city,
    state: req.body.state,
    notes: req.body.notes,
    assignedEmployee: req.body.assignedEmployee,
    status: req.body.status,
    subscriptionPlan: req.body.subscriptionPlan,
    subscriptionAmount: parseFloat(req.body.subscriptionAmount) || 0,
    renewalDate: req.body.renewalDate || null
  };

  dataService.update('customers.json', req.params.id, updates);
  if (oldStatus !== updates.status) {
    dataService.logActivity('lead_status_changed', {
      customerId: req.params.id,
      oldStatus,
      newStatus: updates.status
    }, req.session.user.id);
  }
  dataService.logActivity('customer_updated', { customerId: req.params.id }, req.session.user.id);
  req.flash('success', 'Customer updated successfully');
  res.redirect(`/customers/${req.params.id}`);
};

exports.destroy = (req, res) => {
  const customer = dataService.getById('customers.json', req.params.id);
  if (!customer) return res.status(404).render('error', { title: 'Not Found', message: 'Customer not found' });
  dataService.remove('customers.json', req.params.id);
  dataService.logActivity('customer_deleted', { customerId: req.params.id, name: customer.name }, req.session.user.id);
  req.flash('success', 'Customer deleted successfully');
  res.redirect('/customers');
};

exports.addNote = (req, res) => {
  const customer = dataService.getById('customers.json', req.params.id);
  if (!customer) return res.status(404).render('error', { title: 'Not Found', message: 'Customer not found' });

  const notes = customer.notes || '';
  const newNote = `[${moment().format('DD/MM/YYYY HH:mm')}] ${req.body.note}`;
  dataService.update('customers.json', req.params.id, {
    notes: notes ? `${notes}\n\n${newNote}` : newNote
  });
  dataService.logActivity('note_added', { customerId: req.params.id }, req.session.user.id);
  req.flash('success', 'Note added');
  res.redirect(`/customers/${req.params.id}`);
};

exports.exportCSV = (req, res) => {
  const { Parser } = require('json2csv');
  const user = req.session.user;
  let customers = dataService.getAll('customers.json');
  if (user.role === 'supervisor') {
    customers = customers.filter(c => c.assignedEmployee === user.id);
  }

  const fields = [
    'name', 'businessName', 'mobile', 'whatsappNumber', 'email',
    'city', 'state', 'status', 'assignedEmployeeName', 'createdAt'
  ];

  const employees = dataService.getAll('employees.json');
  const data = customers.map(c => ({
    ...c,
    assignedEmployeeName: employees.find(e => e.id === c.assignedEmployee)?.name || 'Unassigned',
    createdAt: moment(c.createdAt).format('DD/MM/YYYY')
  }));

  const parser = new Parser({ fields });
  const csv = parser.parse(data);
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename=customers.csv');
  res.send(csv);
};
