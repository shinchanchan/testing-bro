const { validationResult } = require('express-validator');
const dataService = require('../services/dataService');

const templateTypes = [
  { value: 'text', label: 'Text Template' },
  { value: 'image', label: 'Image + Text Template' },
  { value: 'video', label: 'Video + Text Template' },
  { value: 'document', label: 'PDF + Text Template' },
  { value: 'button', label: 'Button Template' },
  { value: 'url_button', label: 'URL Button Template' }
];

const categories = ['Follow-up', 'Welcome', 'Payment Reminder', 'Proposal', 'Re-engagement', 'Offer', 'General'];

exports.index = (req, res) => {
  const templates = dataService.getAll('templates.json');
  res.render('templates/index', { title: 'Templates', templates });
};

exports.create = (req, res) => {
  res.render('templates/create', { title: 'Create Template', errors: [], data: {}, templateTypes, categories });
};

exports.store = (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.render('templates/create', { title: 'Create Template', errors: errors.array(), data: req.body, templateTypes, categories });
  }

  const template = {
    name: req.body.name,
    category: req.body.category,
    type: req.body.type,
    messageContent: req.body.messageContent,
    mediaUrl: req.body.mediaUrl,
    buttonText: req.body.buttonText,
    buttonUrl: req.body.buttonUrl,
    filename: req.body.filename
  };

  const newTemplate = dataService.create('templates.json', template);
  dataService.logActivity('template_created', { templateId: newTemplate.id, name: newTemplate.name }, req.session.user.id);
  req.flash('success', 'Template created successfully');
  res.redirect('/templates');
};

exports.edit = (req, res) => {
  const template = dataService.getById('templates.json', req.params.id);
  if (!template) return res.status(404).render('error', { title: 'Not Found', message: 'Template not found' });
  res.render('templates/edit', { title: 'Edit Template', errors: [], template, templateTypes, categories });
};

exports.update = (req, res) => {
  const errors = validationResult(req);
  const template = dataService.getById('templates.json', req.params.id);
  if (!template) return res.status(404).render('error', { title: 'Not Found', message: 'Template not found' });

  if (!errors.isEmpty()) {
    return res.render('templates/edit', { title: 'Edit Template', errors: errors.array(), template: { ...template, ...req.body }, templateTypes, categories });
  }

  dataService.update('templates.json', req.params.id, {
    name: req.body.name,
    category: req.body.category,
    type: req.body.type,
    messageContent: req.body.messageContent,
    mediaUrl: req.body.mediaUrl,
    buttonText: req.body.buttonText,
    buttonUrl: req.body.buttonUrl,
    filename: req.body.filename
  });

  dataService.logActivity('template_updated', { templateId: req.params.id }, req.session.user.id);
  req.flash('success', 'Template updated successfully');
  res.redirect('/templates');
};

exports.destroy = (req, res) => {
  const template = dataService.getById('templates.json', req.params.id);
  if (!template) return res.status(404).render('error', { title: 'Not Found', message: 'Template not found' });
  dataService.remove('templates.json', req.params.id);
  dataService.logActivity('template_deleted', { templateId: req.params.id, name: template.name }, req.session.user.id);
  req.flash('success', 'Template deleted successfully');
  res.redirect('/templates');
};
