const { validationResult } = require('express-validator');
const dataService = require('../services/dataService');
const moment = require('moment');

exports.index = (req, res) => {
  const user = req.session.user;
  let payments = dataService.getAll('payments.json');
  const customers = dataService.getAll('customers.json');

  if (user.role === 'supervisor') {
    const myCustomerIds = customers.filter(c => c.assignedEmployee === user.id).map(c => c.id);
    payments = payments.filter(p => myCustomerIds.includes(p.customerId));
  }

  res.render('payments/index', {
    title: 'Payments',
    payments: payments.sort((a, b) => new Date(b.dueDate) - new Date(a.dueDate)),
    customers,
    moment
  });
};

exports.create = (req, res) => {
  const customers = dataService.getAll('customers.json');
  res.render('payments/create', { title: 'Add Payment', errors: [], data: {}, customers });
};

exports.store = (req, res) => {
  const errors = validationResult(req);
  const customers = dataService.getAll('customers.json');
  if (!errors.isEmpty()) {
    return res.render('payments/create', { title: 'Add Payment', errors: errors.array(), data: req.body, customers });
  }

  const payment = dataService.create('payments.json', {
    customerId: req.body.customerId,
    plan: req.body.plan,
    amount: parseFloat(req.body.amount),
    startDate: req.body.startDate,
    dueDate: req.body.dueDate,
    paidDate: req.body.paidDate || null,
    status: req.body.status || 'pending'
  });

  dataService.logActivity('payment_created', { paymentId: payment.id, customerId: req.body.customerId }, req.session.user.id);
  req.flash('success', 'Payment record added');
  res.redirect('/payments');
};

exports.edit = (req, res) => {
  const payment = dataService.getById('payments.json', req.params.id);
  if (!payment) return res.status(404).render('error', { title: 'Not Found', message: 'Payment not found' });
  const customers = dataService.getAll('customers.json');
  res.render('payments/edit', { title: 'Edit Payment', errors: [], payment, customers });
};

exports.update = (req, res) => {
  const errors = validationResult(req);
  const payment = dataService.getById('payments.json', req.params.id);
  if (!payment) return res.status(404).render('error', { title: 'Not Found', message: 'Payment not found' });

  const customers = dataService.getAll('customers.json');
  if (!errors.isEmpty()) {
    return res.render('payments/edit', { title: 'Edit Payment', errors: errors.array(), payment: { ...payment, ...req.body }, customers });
  }

  dataService.update('payments.json', req.params.id, {
    customerId: req.body.customerId,
    plan: req.body.plan,
    amount: parseFloat(req.body.amount),
    startDate: req.body.startDate,
    dueDate: req.body.dueDate,
    paidDate: req.body.paidDate || null,
    status: req.body.status
  });

  dataService.logActivity('payment_updated', { paymentId: req.params.id }, req.session.user.id);
  req.flash('success', 'Payment record updated');
  res.redirect('/payments');
};

exports.destroy = (req, res) => {
  const payment = dataService.getById('payments.json', req.params.id);
  if (!payment) return res.status(404).render('error', { title: 'Not Found', message: 'Payment not found' });
  dataService.remove('payments.json', req.params.id);
  dataService.logActivity('payment_deleted', { paymentId: req.params.id }, req.session.user.id);
  req.flash('success', 'Payment record deleted');
  res.redirect('/payments');
};
