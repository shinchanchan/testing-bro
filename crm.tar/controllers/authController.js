const bcrypt = require('bcryptjs');
const { validationResult } = require('express-validator');
const { loginUser } = require('../middleware/auth');
const dataService = require('../services/dataService');

exports.getLogin = (req, res) => {
  res.render('auth/login', { title: 'Login', errors: [] });
};

exports.postLogin = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.render('auth/login', { title: 'Login', errors: errors.array() });
  }

  const { email, password } = req.body;
  const user = await loginUser(email, password);
  if (!user) {
    req.flash('error', 'Invalid email or password');
    return res.redirect('/login');
  }

  req.session.user = user;
  dataService.logActivity('login', { userId: user.id, email: user.email }, user.id);
  req.flash('success', `Welcome back, ${user.name}`);
  res.redirect('/dashboard');
};

exports.logout = (req, res) => {
  if (req.session.user) {
    dataService.logActivity('logout', { userId: req.session.user.id }, req.session.user.id);
  }
  req.session.destroy();
  res.redirect('/login');
};

exports.getProfile = (req, res) => {
  res.render('auth/profile', { title: 'My Profile', errors: [] });
};

exports.postProfile = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.render('auth/profile', { title: 'My Profile', errors: errors.array() });
  }

  const { name, mobile, currentPassword, newPassword } = req.body;
  const user = dataService.getById('employees.json', req.session.user.id);

  const updates = { name, mobile };
  if (currentPassword && newPassword) {
    const valid = await bcrypt.compare(currentPassword, user.passwordHash);
    if (!valid) {
      req.flash('error', 'Current password is incorrect');
      return res.redirect('/profile');
    }
    updates.passwordHash = await bcrypt.hash(newPassword, 10);
  }

  dataService.update('employees.json', req.session.user.id, updates);
  req.session.user = { ...req.session.user, name, mobile };
  dataService.logActivity('profile_updated', { userId: req.session.user.id }, req.session.user.id);
  req.flash('success', 'Profile updated successfully');
  res.redirect('/profile');
};
