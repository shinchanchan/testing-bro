const { validationResult } = require('express-validator');
const dataService = require('../services/dataService');
const whatsappService = require('../services/whatsappService');
const moment = require('moment');

exports.config = (req, res) => {
  const config = whatsappService.getConfig();
  res.render('whatsapp/config', { title: 'WhatsApp Configuration', config, errors: [] });
};

exports.updateConfig = (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.render('whatsapp/config', { title: 'WhatsApp Configuration', config: req.body, errors: errors.array() });
  }

  const config = {
    appId: req.body.appId,
    appSecret: req.body.appSecret,
    phoneNumberId: req.body.phoneNumberId,
    whatsappBusinessAccountId: req.body.whatsappBusinessAccountId,
    accessToken: req.body.accessToken,
    apiVersion: req.body.apiVersion || 'v18.0',
    enabled: req.body.enabled === 'on'
  };

  dataService.writeFile('whatsapp.json', config, true);
  dataService.logActivity('whatsapp_config_updated', {}, req.session.user.id);
  req.flash('success', 'WhatsApp configuration saved');
  res.redirect('/whatsapp/config');
};

// New WhatsApp Chat Interface
exports.chat = (req, res) => {
  const customers = dataService.getAll('customers.json');
  const templates = dataService.getAll('templates.json');
  const messages = whatsappService.getMessages();

  // Group messages by contact phone
  const contactsMap = {};
  messages.forEach(m => {
    if (!contactsMap[m.to]) contactsMap[m.to] = { lastMessage: m, count: 0 };
    contactsMap[m.to].lastMessage = m;
    contactsMap[m.to].count++;
  });

  // Build contact list from customers + any existing message recipients
  const contactList = customers.map(c => {
    const phone = whatsappService.formatPhone(c.whatsappNumber || c.mobile);
    return {
      id: c.id,
      name: c.name,
      phone,
      businessName: c.businessName,
      avatar: c.name.charAt(0).toUpperCase(),
      lastMessage: contactsMap[phone]?.lastMessage || null,
      unreadCount: 0
    };
  }).sort((a, b) => {
    if (!a.lastMessage) return 1;
    if (!b.lastMessage) return -1;
    return new Date(b.lastMessage.sentAt) - new Date(a.lastMessage.sentAt);
  });

  res.render('whatsapp/chat', {
    title: 'WhatsApp Chat',
    customers,
    templates,
    contactList,
    moment,
    selectedPhone: req.query.phone || null
  });
};

exports.getMessages = (req, res) => {
  const phone = req.params.phone;
  const messages = whatsappService.getMessages(phone);
  res.json({ success: true, messages });
};

exports.sendChatMessage = async (req, res) => {
  const { phone, message, type, mediaUrl, buttonText, buttonUrl, templateId } = req.body;

  let messageData = { body: message };
  let messageType = type || 'text';

  if (templateId) {
    const templates = dataService.getAll('templates.json');
    const template = templates.find(t => t.id === templateId);
    if (template) {
      messageData = {
        body: template.messageContent,
        mediaUrl: template.mediaUrl,
        caption: template.messageContent,
        buttonText: template.buttonText,
        buttonUrl: template.buttonUrl,
        filename: template.filename
      };
      messageType = template.type;
    }
  } else {
    messageData = {
      body: message,
      mediaUrl,
      caption: message,
      buttonText,
      buttonUrl
    };
  }

  const result = await whatsappService.sendMessage(phone, messageData, messageType);

  if (result.success) {
    dataService.logActivity('whatsapp_message_sent', { to: phone, type: messageType }, req.session.user.id);
    return res.json({ success: true, message: result.data });
  }

  res.status(400).json({ success: false, error: result.error });
};

exports.sendBulkChat = async (req, res) => {
  const { phones, message, templateId } = req.body;
  const templates = dataService.getAll('templates.json');
  const template = templates.find(t => t.id === templateId);

  const results = [];
  for (const phone of phones) {
    let result;
    if (template) {
      result = await whatsappService.sendTemplate(phone, template);
    } else {
      result = await whatsappService.sendMessage(phone, { body: message }, 'text');
    }
    results.push({ phone, ...result });
  }

  dataService.logActivity('bulk_whatsapp_sent', { count: phones.length, templateId }, req.session.user.id);
  res.json({ success: true, results });
};

exports.send = (req, res) => {
  res.redirect('/whatsapp/chat');
};

exports.doSend = async (req, res) => {
  res.redirect('/whatsapp/chat');
};

exports.bulk = (req, res) => {
  res.redirect('/whatsapp/chat');
};

exports.doBulk = async (req, res) => {
  res.redirect('/whatsapp/chat');
};

exports.test = async (req, res) => {
  const result = await whatsappService.testConnection();
  if (result.success) {
    req.flash('success', 'WhatsApp connection successful');
  } else {
    req.flash('error', result.error);
  }
  res.redirect('/whatsapp/config');
};

exports.logs = (req, res) => {
  const logs = dataService.query('logs.json', l =>
    l.action === 'whatsapp_message_sent' || l.action === 'bulk_whatsapp_sent'
  ).sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  res.render('whatsapp/logs', { title: 'WhatsApp Message Logs', logs });
};
