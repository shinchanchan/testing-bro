const bcrypt = require('bcryptjs');
const { validationResult } = require('express-validator');
const dataService = require('../services/dataService');
const reportService = require('../services/reportService');
const moment = require('moment');

exports.index = (req, res) => {
  const employees = dataService.getAll('employees.json');
  res.render('employees/index', { title: 'Employees', employees, moment });
};

exports.create = (req, res) => {
  res.render('employees/create', { title: 'Add Employee', errors: [], data: {} });
};


exports.store = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.render('employees/create', { title: 'Add Employee', errors: errors.array(), data: req.body });
  }

  const existing = dataService.getAll('employees.json').find(e => e.email.toLowerCase() === req.body.email.toLowerCase());
  if (existing) {
    req.flash('error', 'Email already exists');
    return res.redirect('/employees/create');
  }

  const employee = {
    employeeId: req.body.employeeId,
    name: req.body.name,
    mobile: req.body.mobile,
    email: req.body.email,
    department: req.body.department,
    role: req.body.role,
    passwordHash: await bcrypt.hash(req.body.password, 10),
    isActive: true,
    createdAt: new Date().toISOString()
  };

  const newEmployee = dataService.create('employees.json', employee);
  dataService.logActivity('employee_created', { employeeId: newEmployee.id, name: newEmployee.name }, req.session.user.id);
  req.flash('success', 'Employee created successfully');
  res.redirect('/employees');
};

exports.edit = (req, res) => {
  const employee = dataService.getById('employees.json', req.params.id);
  if (!employee) return res.status(404).render('error', { title: 'Not Found', message: 'Employee not found' });
  res.render('employees/edit', { title: 'Edit Employee', errors: [], employee });
};

exports.update = async (req, res) => {
  const errors = validationResult(req);
  const employee = dataService.getById('employees.json', req.params.id);
  if (!employee) return res.status(404).render('error', { title: 'Not Found', message: 'Employee not found' });

  if (!errors.isEmpty()) {
    return res.render('employees/edit', { title: 'Edit Employee', errors: errors.array(), employee: { ...employee, ...req.body } });
  }

  const updates = {
    employeeId: req.body.employeeId,
    name: req.body.name,
    mobile: req.body.mobile,
    email: req.body.email,
    department: req.body.department,
    role: req.body.role,
    isActive: req.body.isActive === 'true'
  };

  if (req.body.password) {
    updates.passwordHash = await bcrypt.hash(req.body.password, 10);
  }

  dataService.update('employees.json', req.params.id, updates);
  dataService.logActivity('employee_updated', { employeeId: req.params.id }, req.session.user.id);
  req.flash('success', 'Employee updated successfully');
  res.redirect('/employees');
};

exports.destroy = (req, res) => {
  const employee = dataService.getById('employees.json', req.params.id);
  if (!employee) return res.status(404).render('error', { title: 'Not Found', message: 'Employee not found' });
  dataService.remove('employees.json', req.params.id);
  dataService.logActivity('employee_deleted', { employeeId: req.params.id, name: employee.name }, req.session.user.id);
  req.flash('success', 'Employee deleted successfully');
  res.redirect('/employees');
};

exports.performance = (req, res) => {
  const performance = reportService.getEmployeePerformance();
  res.render('employees/performance', { title: 'Employee Performance', performance });
};
