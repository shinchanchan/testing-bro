const { validationResult } = require('express-validator');
const dataService = require('../services/dataService');
const whatsappService = require('../services/whatsappService');
const moment = require('moment');

exports.index = (req, res) => {
  const user = req.session.user;
  let followups = dataService.getAll('followups.json');
  const customers = dataService.getAll('customers.json');

  if (user.role === 'supervisor') {
    followups = followups.filter(f => {
      const customer = customers.find(c => c.id === f.customerId);
      return customer && customer.assignedEmployee === user.id;
    });
  }

  const { status, type } = req.query;
  if (status) followups = followups.filter(f => f.status === status);
  if (type) followups = followups.filter(f => f.type === type);

  res.render('followups/index', {
    title: 'Follow-ups',
    followups: followups.sort((a, b) => new Date(b.scheduledDate) - new Date(a.scheduledDate)),
    customers,
    filters: { status, type },
    moment
  });
};

exports.create = (req, res) => {
  const customers = dataService.getAll('customers.json');
  const templates = dataService.getAll('templates.json');
  res.render('followups/create', { title: 'Schedule Follow-up', errors: [], data: {}, customers, templates });
};

exports.store = (req, res) => {
  const errors = validationResult(req);
  const customers = dataService.getAll('customers.json');
  const templates = dataService.getAll('templates.json');

  if (!errors.isEmpty()) {
    return res.render('followups/create', { title: 'Schedule Follow-up', errors: errors.array(), data: req.body, customers, templates });
  }

  const customer = customers.find(c => c.id === req.body.customerId);
  const template = templates.find(t => t.id === req.body.templateId);

  const followUp = dataService.create('followups.json', {
    customerId: req.body.customerId,
    customerName: customer?.name,
    ruleName: req.body.ruleName || 'Manual',
    type: req.body.type || 'manual',
    scheduledDate: req.body.scheduledDate,
    messageContent: req.body.messageContent || template?.messageContent || '',
    templateId: req.body.templateId || null,
    status: 'scheduled'
  });

  dataService.logActivity('followup_scheduled', { followUpId: followUp.id, customerId: req.body.customerId }, req.session.user.id);
  req.flash('success', 'Follow-up scheduled successfully');
  res.redirect('/followups');
};

exports.complete = async (req, res) => {
  const followUp = dataService.getById('followups.json', req.params.id);
  if (!followUp) return res.status(404).render('error', { title: 'Not Found', message: 'Follow-up not found' });

  const customer = dataService.getById('customers.json', followUp.customerId);

  // Auto-send WhatsApp if enabled and has template
  let sent = false;
  if (customer && customer.whatsappNumber && followUp.templateId) {
    const templates = dataService.getAll('templates.json');
    const template = templates.find(t => t.id === followUp.templateId);
    if (template) {
      const result = await whatsappService.sendTemplate(customer.whatsappNumber, template);
      sent = result.success;
    }
  }

  dataService.update('followups.json', req.params.id, {
    status: 'completed',
    completedAt: new Date().toISOString(),
    sent,
    notes: req.body.notes
  });

  dataService.logActivity('followup_completed', { followUpId: req.params.id, customerId: followUp.customerId }, req.session.user.id);
  req.flash('success', 'Follow-up marked as completed');
  res.redirect('/followups');
};

exports.destroy = (req, res) => {
  const followUp = dataService.getById('followups.json', req.params.id);
  if (!followUp) return res.status(404).render('error', { title: 'Not Found', message: 'Follow-up not found' });
  dataService.remove('followups.json', req.params.id);
  dataService.logActivity('followup_deleted', { followUpId: req.params.id }, req.session.user.id);
  req.flash('success', 'Follow-up deleted');
  res.redirect('/followups');
};
