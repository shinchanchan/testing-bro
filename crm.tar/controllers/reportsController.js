const moment = require('moment');
const dataService = require('../services/dataService');
const reportService = require('../services/reportService');

exports.index = (req, res) => {
  const { type = 'leads', period = 'monthly' } = req.query;
  const user = req.session.user;
  const today = moment();

  let customers = dataService.getAll('customers.json');
  if (user.role === 'supervisor') {
    customers = customers.filter(c => c.assignedEmployee === user.id);
  }

  let filteredCustomers = customers;
  if (period === 'daily') {
    filteredCustomers = customers.filter(c => moment(c.createdAt).isSame(today, 'day'));
  } else if (period === 'weekly') {
    filteredCustomers = customers.filter(c => moment(c.createdAt).isSame(today, 'week'));
  } else if (period === 'monthly') {
    filteredCustomers = customers.filter(c => moment(c.createdAt).isSame(today, 'month'));
  }

  const stats = {
    total: filteredCustomers.length,
    converted: filteredCustomers.filter(c => c.status === 'Converted').length,
    lost: filteredCustomers.filter(c => c.status === 'Lost').length,
    inProgress: filteredCustomers.filter(c => !['Converted', 'Lost'].includes(c.status)).length
  };

  const performance = reportService.getEmployeePerformance();
  const monthlySales = reportService.getMonthlySales();

  res.render('reports/index', {
    title: 'Reports',
    type,
    period,
    stats,
    performance,
    monthlySales,
    moment
  });
};
