const reportService = require('../services/reportService');
const notificationService = require('../services/notificationService');
const dataService = require('../services/dataService');
const moment = require('moment');

exports.index = (req, res) => {
  const user = req.session.user;
  const stats = reportService.getDashboardStats(user);
  const pipeline = reportService.getLeadPipelineData(user);
  const notifications = notificationService.getNotifications(user);
  const recentCustomers = dataService.getAll('customers.json')
    .filter(c => !user || user.role === 'superadmin' || c.assignedEmployee === user.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 5);

  const recentActivity = dataService.getAll('logs.json')
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
    .slice(0, 10);

  res.render('dashboard/index', {
    title: 'Dashboard',
    stats,
    pipeline,
    notifications,
    recentCustomers,
    recentActivity,
    moment
  });
};
