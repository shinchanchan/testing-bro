# WhatsApp CRM & Sales Follow-Up System

A production-ready CRM application built with Node.js, Express.js, EJS, Tailwind CSS, DaisyUI, and JSON file storage.

## Features

- **Role-Based Access Control**: Super Admin and Supervisor roles
- **Customer Management**: Complete customer profiles with contact details, addresses, notes, and subscription info
- **Lead Pipeline**: Drag-and-drop Kanban board with status tracking
- **WhatsApp Business API**: Meta Cloud API integration for text, image, video, PDF, and button messages
- **Template Management**: Create and manage WhatsApp message templates
- **Follow-Up Automation**: Automated follow-up schedule (Day 1, 3, 7, 15, 30, 45, 60)
- **Payment Reminders**: Automatic payment due reminders
- **Employee Management**: Create employees, assign leads, track performance
- **Reports & Analytics**: Dashboard widgets, Chart.js charts, performance reports
- **Activity Logs**: Track all important actions
- **Notifications**: Real-time notification bell for follow-ups and payments
- **CSV Export**: Export customer data
- **Dark Mode**: Toggle between light and dark themes
- **Auto Backup**: Automatic JSON file backups

## Tech Stack

- Node.js
- Express.js
- EJS Templates
- Tailwind CSS
- DaisyUI
- Lucide Icons
- Chart.js
- bcryptjs (password hashing)
- express-session (session auth)
- csurf (CSRF protection)
- helmet (security headers)

## Installation

```bash
npm install
```

## Development

```bash
# Start server
npm run dev

# Build CSS (in another terminal)
npm run build:css
```

## Production

```bash
# Build CSS once
npm run build:css:once

# Start server
npm start
```

## Default Login

- Email: `admin@crm.local`
- Password: `password`

## Configuration

Copy `.env.example` to `.env` and update values:

```bash
cp .env.example .env
```

Configure WhatsApp Business API in the app under Settings > WhatsApp Configuration.

## Folder Structure

```
├── app.js
├── routes/
├── controllers/
├── middleware/
├── services/
├── views/
├── public/
├── config/
├── data/
├── uploads/
└── backups/
```

## License

MIT
